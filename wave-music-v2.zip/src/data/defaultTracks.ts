/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Track, TrackSource, AudioFormat } from "../types";
import { generateSynthesizedWav } from "../utils/wavGenerator";

// Helper to generate realistic waveform points (0 to 100)
const generateWaveformData = (seed: number): number[] => {
  const points: number[] = [];
  for (let i = 0; i < 200; i++) {
    const val = 15 + Math.sin(i * 0.1) * 10 + Math.cos(i * 0.05 + seed) * 15 + Math.sin(i * 0.3) * 5 + (i % 7 ? 5 : -5);
    points.push(Math.max(4, Math.min(95, Math.round(val))));
  }
  return points;
};

export const DEFAULT_TRACKS: Track[] = [
  {
    id: "neon-dream",
    title: "Neon Horizon (Hyper-Drive)",
    artist: "Retro Dynamic",
    album: "Futura 2088",
    albumArtUri: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=500&auto=format&fit=crop&q=80",
    filePath: generateSynthesizedWav("neon", 191),
    source: TrackSource.LOCAL,
    duration: 191,
    bitrate: 320,
    sampleRate: 48000,
    bitDepth: 24,
    fileSize: 14.2,
    format: AudioFormat.FLAC,
    genre: "Synthwave",
    year: 2026,
    playCount: 142,
    isLiked: true,
    lufsValue: -14.2,
    waveformData: generateWaveformData(12),
    lyricsSynced: [
      { time: 0, text: "🎵 [Ambient Synths Fade In] 🎵" },
      { time: 5, text: "Welcome to the neon twilight grid..." },
      { time: 10, text: "The stars align, just like we always did." },
      { time: 14, text: "Accelerating down the cosmic highway of chrome" },
      { time: 19, text: "Searching for the signal that'll lead us back home." },
      { time: 24, text: "Speed of light, shifting gears into sound..." },
      { time: 29, text: "With the bass pulsing high, we are leaving the ground!" },
      { time: 34, text: "Oh, feel the static charge in your fingers tonight," },
      { time: 39, text: "As the parametric waveforms catch the digital light!" },
      { time: 44, text: "🎵 [Synthesizer Solo Interlude] 🎵" },
      { time: 54, text: "Double-tap the grid, activate the bypass chain" },
      { time: 59, text: "We are running on pure power, breaking the mechanical reign." },
      { time: 64, text: "Can you hear the reverberation in the stereo space?" },
      { time: 69, text: "One thousand XM5s reflecting your beautiful face." },
      { time: 74, text: "Let the dynamic compression hold our gravity tight," },
      { time: 79, text: "Underneath the cyber canopy, we're flying tonight." },
      { time: 84, text: "🎵 [Bass Dropping - Liquid Widening Dynamic Active] 🎵" }
    ]
  },
  {
    id: "moonlight-nocturne",
    title: "Nocturne Op. 9 No. 2 (High-Res Piano)",
    artist: "Chopin Ensemble",
    album: "Classical Chillouts",
    albumArtUri: "https://images.unsplash.com/photo-1520523839897-bd0b52f945a0?w=500&auto=format&fit=crop&q=80",
    filePath: generateSynthesizedWav("chopin", 211),
    source: TrackSource.ARCHIVE,
    duration: 211,
    bitrate: 1411,
    sampleRate: 44100,
    bitDepth: 16,
    fileSize: 42.1,
    format: AudioFormat.WAV,
    genre: "Classical",
    year: 1832,
    playCount: 89,
    isLiked: false,
    lufsValue: -18.5,
    waveformData: generateWaveformData(44),
    lyricsSynced: [
      { time: 0, text: "🎹 [Gentle Piano Introduction - Chopin's Nocturne] 🎹" },
      { time: 12, text: "The first melody floats softly into the night..." },
      { time: 23, text: "A delicate dance of black and white, pure and bright." },
      { time: 34, text: "Hear the quiet sustain echoing through the drafty hall," },
      { time: 45, text: "As the shadows of Chopin's thoughts climb the high stone wall." },
      { time: 57, text: "The left hand sways, a comforting boat on the tide," },
      { time: 68, text: "While the right hand wanders with nowhere left to hide." },
      { time: 80, text: "🎵 [Cascading romantic embellishments] 🎵" },
      { time: 92, text: "Slowing down... feeling the weight of the sweet key touch," },
      { time: 104, text: "In this quiet nocturne, we don't need to ask for much." }
    ]
  },
  {
    id: "lofi-rain",
    title: "Liquid Glass Rainfall",
    artist: "Lofi Horizon",
    album: "Rainy Cafe Study beats",
    albumArtUri: "https://images.unsplash.com/photo-1485594050903-8e8ee7b071a8?w=500&auto=format&fit=crop&q=80",
    filePath: generateSynthesizedWav("lofi", 385),
    source: TrackSource.LOCAL,
    duration: 385,
    bitrate: 256,
    sampleRate: 44100,
    bitDepth: 16,
    fileSize: 8.4,
    format: AudioFormat.MP3,
    genre: "Lofi Hip-Hop",
    year: 2025,
    playCount: 1205,
    isLiked: true,
    lufsValue: -15.1,
    waveformData: generateWaveformData(81),
    lyricsSynced: [
      { time: 0, text: "🌧️ [Soft crackling vinyl and distant storm rain] 🌧️" },
      { time: 10, text: "Pouring down, window panes fogging up now." },
      { time: 18, text: "Got my hot coffee, letting go of the stress somehow." },
      { time: 27, text: "Pencil scratches, pages turning, lo-fi in the air," },
      { time: 36, text: "With the JVC headphones, we haven't got a single care." },
      { time: 45, text: "Sipping slow, as the tape wheel revolves" },
      { time: 54, text: "Every problem dissolves, as the compressor solves..." },
      { time: 63, text: "🌧️ [Vinyl Crackling & Rain Ambient Section] 🌧️" }
    ]
  },
  {
    id: "vintage-groove",
    title: "Acoustic Serenade",
    artist: "Evelyn & The Strings",
    album: "Cabin Sessions",
    albumArtUri: "https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?w=500&auto=format&fit=crop&q=80",
    filePath: generateSynthesizedWav("acoustic", 172),
    source: TrackSource.LOCAL,
    duration: 172,
    bitrate: 320,
    sampleRate: 44100,
    bitDepth: 24,
    fileSize: 13.1,
    format: AudioFormat.FLAC,
    genre: "Acoustic Folk",
    year: 2024,
    playCount: 76,
    isLiked: false,
    lufsValue: -13.0,
    waveformData: generateWaveformData(98),
    lyricsSynced: [
      { time: 0, text: "🎸 [Warm hand-plucked acoustic guitar intro] 🎸" },
      { time: 8, text: "Pack your heavy bags, we are bound for the pines." },
      { time: 15, text: "Crossing over mountains and the golden state lines." },
      { time: 22, text: "Singing through the valley where the wild winds blow," },
      { time: 30, text: "Take it sweet and easy, let the acoustic river flow." },
      { time: 38, text: "Let the harmonic exciter bring the wooden strings alive," },
      { time: 46, text: "With a little stereo widener, the acoustics will survive!" }
    ]
  }
];
