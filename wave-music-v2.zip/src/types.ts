/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum TrackSource {
  LOCAL = "LOCAL",
  SPOTIFY = "SPOTIFY",
  DEEZER = "DEEZER",
  SOUNDCLOUD = "SOUNDCLOUD",
  YOUTUBE = "YOUTUBE",
  ARCHIVE = "ARCHIVE"
}

export enum AudioFormat {
  MP3 = "MP3",
  FLAC = "FLAC",
  AAC = "AAC",
  WAV = "WAV",
  OPUS = "OPUS",
  OGG = "OGG"
}

export interface Track {
  id: string;
  title: string;
  artist: string;
  album: string;
  albumArtUri: string;
  filePath: string;
  source: TrackSource;
  streamId?: string;
  duration: number; // in seconds
  bitrate: number; // in kbps
  sampleRate: number; // in Hz
  bitDepth: number; // 16, 24, 32
  fileSize: number; // in MB
  format: AudioFormat;
  genre?: string;
  year?: number;
  playCount: number;
  isLiked: boolean;
  lufsValue?: number;
  replayGain?: number;
  waveformData?: number[]; // Waveform pre-analysis points 0-100
  lyricsSynced?: LyricsLine[];
}

export interface LyricsLine {
  time: number; // in seconds
  text: string;
}

export interface EQBand {
  frequency: number;
  gain: number; // -12 to +12 dB
  q: number; // resonance/bandwidth
}

export interface EQPreset {
  id: string;
  name: string;
  bands: EQBand[];
  isBuiltIn: boolean;
}

export interface BluetoothProfile {
  mac?: string;
  deviceName: string;
  brand: string;
  presetId: string;
  codecPreference: string;
}

export enum VisualizerMode {
  SPECTRUM = "SPECTRUM",
  WAVEFORM = "WAVEFORM",
  CIRCULAR = "CIRCULAR",
  PARTICLES = "PARTICLES"
}
