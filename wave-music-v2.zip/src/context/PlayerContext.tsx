/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect, useRef } from "react";
import { Track, EQPreset, BluetoothProfile, AudioFormat, TrackSource, VisualizerMode } from "../types";
import { engine, BUILT_IN_PRESETS, BRAND_PROFILES, PARAMETRIC_FREQ_STAGES } from "../utils/audioEngine";
import { DEFAULT_TRACKS } from "../data/defaultTracks";
import { generateSynthesizedWav } from "../utils/wavGenerator";

const generateWaveformData = (seed: number): number[] => {
  const points: number[] = [];
  for (let i = 0; i < 200; i++) {
    const val = 15 + Math.sin(i * 0.1) * 10 + Math.cos(i * 0.05 + seed) * 15 + Math.sin(i * 0.3) * 5 + (i % 7 ? 5 : -5);
    points.push(Math.max(4, Math.min(95, Math.round(val))));
  }
  return points;
};

interface PlayerContextType {
  // Playback state
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  progressPercent: number;
  volume: number;
  playbackRate: number;
  
  // Track Queue control
  tracks: Track[];
  queue: Track[];
  currentTrackIndex: number;
  currentTrack: Track | null;
  repeatMode: "off" | "all" | "one";
  isShuffleOn: boolean;

  // DSP & EQ parameters
  dspEnabled: boolean;
  eqGains: number[]; // 10 values
  exciterIntensity: number;
  stereoWidth: number;
  compressorEnabled: boolean;
  audioRateMode: string; // lowest latency, most stable
  dolbyAtmosMode: "auto" | "bypass" | "active";
  systemDolbyActive: boolean;

  // Active Profile Simulation
  connectedDevice: BluetoothProfile | null;
  bluetoothProfiles: BluetoothProfile[];
  
  // Interface styles
  visualizerMode: VisualizerMode;
  nowPlayingStyle: "immersive" | "minimal" | "ambient";
  accentColor: string; // hex
  activeTab: string;

  // Lyrics synced scroll
  currentLyricText: string;
  currentLyricIndex: number;

  // Lists & storage
  playlists: { id: string; name: string; songs: string[]; isSmart?: boolean; description?: string }[];
  likedTrackIds: string[];
  codecDownloads: { id: string; name: string; isDownloaded: boolean; desc: string; size: string }[];

  // Interactive controls
  togglePlay: () => void;
  playTrack: (track: Track, fromList?: Track[]) => void;
  seekTo: (seconds: number) => void;
  setVolume: (vol: number) => void;
  nextTrack: () => void;
  prevTrack: () => void;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  toggleLikeTrack: (trackId: string) => void;
  addNewTrack: (file: File) => void;
  addUrlTrack: (url: string, title?: string, artist?: string) => boolean;

  // DSP Updates
  updateEqBand: (index: number, val: number) => void;
  applyPreset: (presetId: string) => void;
  toggleDsp: () => void;
  updateExciter: (val: number) => void;
  updateStereoWidth: (val: number) => void;
  updateCompressor: (enabled: boolean) => void;
  setDolbyMode: (mode: "auto" | "bypass" | "active") => void;

  // Headwear Profiles
  connectDeviceProfile: (brandName: string) => void;
  disconnectDeviceProfile: () => void;

  // Custom playlists & components actions
  createPlaylist: (name: string, description?: string) => void;
  addTrackToPlaylist: (trackId: string, playlistId: string) => void;
  removeTrackFromPlaylist: (trackId: string, playlistId: string) => void;
  deletePlaylist: (playlistId: string) => void;
  downloadCodec: (codecId: string) => void;
  setVisualizerMode: (mode: VisualizerMode) => void;
  setNowPlayingStyle: (style: "immersive" | "minimal" | "ambient") => void;
  setAccentColor: (color: string) => void;
  setActiveTab: (tab: string) => void;
  triggerRescan: () => void;
  isScanning: boolean;
}

const PlayerContext = createContext<PlayerContextType | undefined>(undefined);

export const PlayerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // --- IN-MEMORY & LOCALSTORAGE ROOT VALUES ---
  const initialTracks = React.useMemo(() => {
    const saved = localStorage.getItem("mg_tracks");
    const parsed = saved ? JSON.parse(saved) : DEFAULT_TRACKS;
    return parsed.map((track: Track) => {
      if (track.id === "neon-dream") {
        return { ...track, filePath: generateSynthesizedWav("neon", 191) };
      }
      if (track.id === "moonlight-nocturne") {
        return { ...track, filePath: generateSynthesizedWav("chopin", 211) };
      }
      if (track.id === "lofi-rain") {
        return { ...track, filePath: generateSynthesizedWav("lofi", 385) };
      }
      if (track.id === "vintage-groove") {
        return { ...track, filePath: generateSynthesizedWav("acoustic", 172) };
      }
      return track;
    });
  }, []);

  const [tracks, setTracks] = useState<Track[]>(initialTracks);
  const [queue, setQueue] = useState<Track[]>(initialTracks);

  const [currentTrackIndex, setCurrentTrackIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [volume, setVolumeState] = useState<number>(0.85);
  const [playbackRate, setPlaybackRate] = useState<number>(1.0);
  const [repeatMode, setRepeatMode] = useState<"off" | "all" | "one">("all");
  const [isShuffleOn, setIsShuffleOn] = useState<boolean>(false);

  // DSP and effects
  const [dspEnabled, setDspEnabled] = useState<boolean>(true);
  const [eqGains, setEqGains] = useState<number[]>(new Array(10).fill(0));
  const [exciterIntensity, setExciterIntensity] = useState<number>(0.15);
  const [stereoWidth, setStereoWidth] = useState<number>(0.25);
  const [compressorEnabled, setCompressorEnabled] = useState<boolean>(true);
  const [audioRateMode, setAudioRateMode] = useState<string>("Balanced");
  const [dolbyAtmosMode, setDolbyAtmosMode] = useState<"auto" | "bypass" | "active">("auto");
  const [systemDolbyActive, setSystemDolbyActive] = useState<boolean>(true);

  // Bluetooth connected device simulation
  const [connectedDevice, setConnectedDevice] = useState<BluetoothProfile | null>(null);

  // View States
  const [visualizerMode, setVisualizerModeState] = useState<VisualizerMode>(VisualizerMode.SPECTRUM);
  const [nowPlayingStyle, setNowPlayingStyleState] = useState<"immersive" | "minimal" | "ambient">("immersive");
  const [accentColor, setAccentColorState] = useState<string>("#00D4FF");
  const [activeTab, setActiveTabState] = useState<string>("home");
  const [isScanning, setIsScanning] = useState<boolean>(false);

  // Synced Lyrics Index tracking
  const [currentLyricText, setCurrentLyricText] = useState<string>("");
  const [currentLyricIndex, setCurrentLyricIndex] = useState<number>(-1);

  // Liked Track ids
  const [likedTrackIds, setLikedTrackIds] = useState<string[]>(() => {
    const saved = localStorage.getItem("mg_liked");
    return saved ? JSON.parse(saved) : ["neon-dream", "lofi-rain"];
  });

  // Codecs available/installed
  const [codecDownloads, setCodecDownloads] = useState<any[]>(() => {
    const saved = localStorage.getItem("mg_codecs");
    return saved ? JSON.parse(saved) : [
      { id: "ffmpeg-core", name: "FFmpeg Core Loader (ALAC/APE/MKA)", isDownloaded: true, desc: "Play Lossless APE, ALAC, and MKAs dynamically", size: "2.1 MB" },
      { id: "dsd-sacd", name: "DSD/SACD Decoder Node", isDownloaded: false, desc: "Converts .dsf and .dff SACD matrices to true float32 PCM", size: "1.4 MB" },
      { id: "tracker", name: "Tracker Impulse Tracker/XM Soundpack", isDownloaded: false, desc: "Plays classic Amiga synth tracker mod files", size: "0.8 MB" }
    ];
  });

  // Playlists
  const [playlists, setPlaylists] = useState<any[]>(() => {
    const saved = localStorage.getItem("mg_playlists");
    return saved ? JSON.parse(saved) : [
      { id: "smart-recent", name: "Recently Added", songs: ["vintage-groove", "lofi-rain"], isSmart: true, description: "Tracks scanned in the last 30 days" },
      { id: "smart-hi-res", name: "Super Hi-Res (WAV/FLAC)", songs: ["neon-dream", "moonlight-nocturne", "vintage-groove"], isSmart: true, description: "Lossless quality mastering profiles" },
      { id: "favs", name: "My Cyber Playlist", songs: ["neon-dream", "lofi-rain"], isSmart: false, description: "Personal curated list of ambient loops" }
    ];
  });

  // Track state syncs to localstorage
  useEffect(() => {
    localStorage.setItem("mg_tracks", JSON.stringify(tracks));
  }, [tracks]);

  useEffect(() => {
    localStorage.setItem("mg_liked", JSON.stringify(likedTrackIds));
  }, [likedTrackIds]);

  useEffect(() => {
    localStorage.setItem("mg_playlists", JSON.stringify(playlists));
  }, [playlists]);

  useEffect(() => {
    localStorage.setItem("mg_codecs", JSON.stringify(codecDownloads));
  }, [codecDownloads]);

  // Current Track calculation
  const currentTrack = queue[currentTrackIndex] || null;

  // --- HTML5 AUDIO EVENT BINDINGS AND SETUP ---
  const initializedEngine = useRef<boolean>(false);

  const initAudioEngine = () => {
    if (!initializedEngine.current) {
      engine.init();
      engine.setDspEnabled(dspEnabled);
      engine.setMasterVolume(volume);
      eqGains.forEach((gain, idx) => engine.setEqGain(idx, gain));
      engine.setExciterIntensity(exciterIntensity);
      engine.setStereoWidth(stereoWidth);
      engine.setCompressorParams(compressorEnabled);
      initializedEngine.current = true;
    }
  };

  useEffect(() => {
    const audio = engine.audio;

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };

    const handleDurationChange = () => {
      setDuration(audio.duration || 0);
    };

    const handleEnded = () => {
      handleTrackEnded();
    };

    const handleError = (e: any) => {
      console.warn("Audio load error detected. Attempting playback rescue path...", e);
      // Fail gracefully: skip to next item in 1.5 seconds so UI indicates problem without seizing
      setTimeout(() => {
        nextTrack();
      }, 2000);
    };

    audio.addEventListener("timeupdate", handleTimeUpdate);
    audio.addEventListener("durationchange", handleDurationChange);
    audio.addEventListener("ended", handleEnded);
    audio.addEventListener("error", handleError);

    return () => {
      audio.removeEventListener("timeupdate", handleTimeUpdate);
      audio.removeEventListener("durationchange", handleDurationChange);
      audio.removeEventListener("ended", handleEnded);
      audio.removeEventListener("error", handleError);
    };
  }, [queue, currentTrackIndex, repeatMode, isShuffleOn]);

  // Dynamic Lyrics Synchronizer
  useEffect(() => {
    if (!currentTrack || !currentTrack.lyricsSynced) {
      setCurrentLyricText("");
      setCurrentLyricIndex(-1);
      return;
    }

    const lyrics = currentTrack.lyricsSynced;
    // Find the latest lyric line where time is <= currentTime
    let activeIndex = -1;
    for (let i = 0; i < lyrics.length; i++) {
      if (currentTime >= lyrics[i].time) {
        activeIndex = i;
      } else {
        break;
      }
    }

    if (activeIndex !== currentLyricIndex) {
      setCurrentLyricIndex(activeIndex);
      setCurrentLyricText(activeIndex >= 0 ? lyrics[activeIndex].text : "");
    }
  }, [currentTime, currentTrack]);

  // Accent extractor based on cover art simulation
  useEffect(() => {
    if (currentTrack) {
      // Deterministic hex based on title length or specific seed to simulate extraction
      const colors = ["#00D4FF", "#7B61FF", "#FF2D87", "#39FF14", "#FFD700", "#FF1493"];
      const code = currentTrack.title.length % colors.length;
      setAccentColorState(colors[code]);
    }
  }, [currentTrack]);

  // End of Track Router
  const handleTrackEnded = () => {
    if (repeatMode === "one") {
      engine.audio.currentTime = 0;
      engine.audio.play().catch(() => {});
    } else {
      nextTrack();
    }
  };

  // --- ACTIONS ---

  const togglePlay = () => {
    initAudioEngine();
    engine.resumeContext();
    if (isPlaying) {
      engine.audio.pause();
      setIsPlaying(false);
    } else {
      if (!engine.audio.src && currentTrack) {
        engine.setSource(currentTrack.filePath);
      }
      engine.audio.play()
        .then(() => {
          setIsPlaying(true);
        })
        .catch(err => {
          console.warn("Context resume aborted. Continuing without nodes direct.", err);
          setIsPlaying(true);
        });
    }
  };

  const playTrack = (track: Track, fromList?: Track[]) => {
    initAudioEngine();
    engine.resumeContext();

    const playList = fromList || tracks;
    setQueue(playList);
    
    const index = playList.findIndex(t => t.id === track.id);
    const resolvedIndex = index >= 0 ? index : 0;
    setCurrentTrackIndex(resolvedIndex);

    engine.setSource(track.filePath);
    engine.audio.load();
    engine.audio.play()
      .then(() => {
        setIsPlaying(true);
      })
      .catch(err => {
        console.error("Playback error:", err);
        setIsPlaying(true); // show active state
      });
  };

  const seekTo = (seconds: number) => {
    initAudioEngine();
    const cleanSeconds = Math.max(0, Math.min(duration, seconds));
    engine.audio.currentTime = cleanSeconds;
    setCurrentTime(cleanSeconds);
  };

  const setVolume = (vol: number) => {
    const cleanVol = Math.max(0, Math.min(1, vol));
    setVolumeState(cleanVol);
    engine.setMasterVolume(cleanVol);
  };

  const nextTrack = () => {
    let nextIdx = currentTrackIndex + 1;
    if (isShuffleOn) {
      nextIdx = Math.floor(Math.random() * queue.length);
    } else if (nextIdx >= queue.length) {
      nextIdx = repeatMode === "all" ? 0 : queue.length - 1;
    }
    
    if (queue[nextIdx]) {
      setCurrentTrackIndex(nextIdx);
      playTrack(queue[nextIdx], queue);
    }
  };

  const prevTrack = () => {
    let prevIdx = currentTrackIndex - 1;
    if (currentTime > 5) {
      seekTo(0);
      return;
    }
    if (prevIdx < 0) {
      prevIdx = repeatMode === "all" ? queue.length - 1 : 0;
    }

    if (queue[prevIdx]) {
      setCurrentTrackIndex(prevIdx);
      playTrack(queue[prevIdx], queue);
    }
  };

  const toggleShuffle = () => {
    setIsShuffleOn(!isShuffleOn);
  };

  const toggleRepeat = () => {
    setRepeatMode(prev => {
      if (prev === "off") return "all";
      if (prev === "all") return "one";
      return "off";
    });
  };

  const toggleLikeTrack = (trackId: string) => {
    setLikedTrackIds(prev => {
      const isLiked = prev.includes(trackId);
      const updated = isLiked ? prev.filter(id => id !== trackId) : [...prev, trackId];
      
      // Update track like lists dynamically
      setTracks(t => t.map(tk => tk.id === trackId ? { ...tk, isLiked: !isLiked } : tk));
      setQueue(q => q.map(tk => tk.id === trackId ? { ...tk, isLiked: !isLiked } : tk));
      
      return updated;
    });
  };

  // Drag and drop new local file loader
  const addNewTrack = (file: File) => {
    const objectUrl = URL.createObjectURL(file);
    const fileId = "dropped_" + Date.now();
    const newTrack: Track = {
      id: fileId,
      title: file.name.replace(/\.[^/.]+$/, ""),
      artist: "Scanned File",
      album: "Local Storage",
      albumArtUri: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&auto=format&fit=crop&q=80",
      filePath: objectUrl,
      source: TrackSource.LOCAL,
      duration: 240, // standard estimate, duration fills on load
      bitrate: 320,
      sampleRate: 44100,
      bitDepth: 16,
      fileSize: Math.round((file.size / (1024 * 1024)) * 10) / 10,
      format: AudioFormat.MP3,
      playCount: 0,
      isLiked: false,
      waveformData: generateWaveformData(32),
      lyricsSynced: [
        { time: 0, text: "🎵 [Playing your loaded local track] 🎵" },
        { time: 5, text: `Loaded file: ${file.name}` },
        { time: 10, text: `Web Audio active: ${dspEnabled ? "YES" : "NO"}` },
        { time: 15, text: "Adjust the 10-band equalizer to fine tune sound." }
      ]
    };

    setTracks(prev => [newTrack, ...prev]);
    setQueue(prev => [newTrack, ...prev]);
    playTrack(newTrack, [newTrack, ...tracks]);
  };

  // Add custom streaming URL
  const addUrlTrack = (url: string, title?: string, artist?: string): boolean => {
    if (!url.startsWith("http://") && !url.startsWith("https://")) {
      return false;
    }

    const t = title || "Online Stream";
    const a = artist || "URL Feed Source";
    const id = "stream_" + Date.now();
    const newTrack: Track = {
      id,
      title: t,
      artist: a,
      album: "Liquid Stream Link",
      albumArtUri: "https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=500&auto=format&fit=crop&q=80",
      filePath: url,
      source: TrackSource.ARCHIVE,
      duration: 300,
      bitrate: 256,
      sampleRate: 44100,
      bitDepth: 16,
      fileSize: 1.2,
      format: AudioFormat.MP3,
      playCount: 1,
      isLiked: false,
      waveformData: generateWaveformData(74),
      lyricsSynced: [
        { time: 0, text: `Stream Link Connected: ${t}` },
        { time: 5, text: `Playing direct HTTP progressive stream: ${url}` },
        { time: 12, text: "10-Band EQ & Exciter DSP engines active." }
      ]
    };

    setTracks(prev => [newTrack, ...prev]);
    setQueue(prev => [newTrack, ...prev]);
    playTrack(newTrack, [newTrack, ...tracks]);
    return true;
  };

  // --- DSP CONTROL MODIFICATIONS ---

  const updateEqBand = (index: number, val: number) => {
    const updated = [...eqGains];
    updated[index] = val;
    setEqGains(updated);
    engine.setEqGain(index, val);
  };

  const applyPreset = (presetId: string) => {
    const found = BUILT_IN_PRESETS.find(p => p.id === presetId);
    if (found) {
      const gains = found.bands.map(b => b.gain);
      setEqGains(gains);
      gains.forEach((g, idx) => engine.setEqGain(idx, g));
    }
  };

  const toggleDsp = () => {
    const nextSt = !dspEnabled;
    setDspEnabled(nextSt);
    engine.setDspEnabled(nextSt);
  };

  const updateExciter = (val: number) => {
    setExciterIntensity(val);
    engine.setExciterIntensity(val);
  };

  const updateStereoWidth = (val: number) => {
    setStereoWidth(val);
    engine.setStereoWidth(val);
  };

  const updateCompressor = (enabled: boolean) => {
    setCompressorEnabled(enabled);
    engine.setCompressorParams(enabled);
  };

  const setDolbyMode = (mode: "auto" | "bypass" | "active") => {
    setDolbyAtmosMode(mode);
    const isBypassed = mode === "bypass";
    setSystemDolbyActive(!isBypassed);
    engine.setDolbyBypass(isBypassed);
  };

  const connectDeviceProfile = (brandName: string) => {
    const profile = BRAND_PROFILES.find(p => p.brand === brandName);
    if (profile) {
      const simulated: BluetoothProfile = {
        brand: profile.brand,
        deviceName: profile.deviceName,
        presetId: profile.brand.toLowerCase(),
        codecPreference: profile.brand === "SONY" ? "LDAC Ultra (990kbps)" : "AAC / aptX HD Audio"
      };
      setConnectedDevice(simulated);
      
      // Auto-Apply gains
      setEqGains(profile.gains);
      profile.gains.forEach((g, idx) => engine.setEqGain(idx, g));
      updateExciter(profile.exciter);
      updateStereoWidth(profile.stereoWidth);
    }
  };

  const disconnectDeviceProfile = () => {
    setConnectedDevice(null);
    // Reset to Flat
    applyPreset("flat");
    updateExciter(0.15);
    updateStereoWidth(0.25);
  };

  // --- PLAYLIST ACTIONS ---

  const createPlaylist = (name: string, description?: string) => {
    const id = "pl_" + Date.now();
    setPlaylists(prev => [
      ...prev,
      { id, name, songs: [], isSmart: false, description: description || "Curated tracks selection" }
    ]);
  };

  const addTrackToPlaylist = (trackId: string, playlistId: string) => {
    setPlaylists(prev => prev.map(pl => {
      if (pl.id === playlistId) {
        if (pl.songs.includes(trackId)) return pl;
        return { ...pl, songs: [...pl.songs, trackId] };
      }
      return pl;
    }));
  };

  const removeTrackFromPlaylist = (trackId: string, playlistId: string) => {
    setPlaylists(prev => prev.map(pl => {
      if (pl.id === playlistId) {
        return { ...pl, songs: pl.songs.filter(id => id !== trackId) };
      }
      return pl;
    }));
  };

  const deletePlaylist = (playlistId: string) => {
    setPlaylists(prev => prev.filter(pl => pl.id !== playlistId));
  };

  const downloadCodec = (codecId: string) => {
    setCodecDownloads(prev => prev.map(codec => {
      if (codec.id === codecId) {
        return { ...codec, isDownloaded: true };
      }
      return codec;
    }));
  };

  const triggerRescan = () => {
    setIsScanning(true);
    setTimeout(() => {
      setIsScanning(false);
    }, 2000);
  };

  // --- HELPERS / MISC EXPORTS ---
  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <PlayerContext.Provider
      value={{
        isPlaying,
        currentTime,
        duration,
        progressPercent,
        volume,
        playbackRate,
        tracks,
        queue,
        currentTrackIndex,
        currentTrack,
        repeatMode,
        isShuffleOn,
        dspEnabled,
        eqGains,
        exciterIntensity,
        stereoWidth,
        compressorEnabled,
        audioRateMode,
        dolbyAtmosMode,
        systemDolbyActive,
        connectedDevice,
        bluetoothProfiles: [], // simulated
        visualizerMode,
        nowPlayingStyle,
        accentColor,
        activeTab,
        currentLyricText,
        currentLyricIndex,
        playlists,
        likedTrackIds,
        codecDownloads,
        togglePlay,
        playTrack,
        seekTo,
        setVolume,
        nextTrack,
        prevTrack,
        toggleShuffle,
        toggleRepeat,
        toggleLikeTrack,
        addNewTrack,
        addUrlTrack,
        updateEqBand,
        applyPreset,
        toggleDsp,
        updateExciter,
        updateStereoWidth,
        updateCompressor,
        setDolbyMode,
        connectDeviceProfile,
        disconnectDeviceProfile,
        createPlaylist,
        addTrackToPlaylist,
        removeTrackFromPlaylist,
        deletePlaylist,
        downloadCodec,
        setVisualizerMode: setVisualizerModeState,
        setNowPlayingStyle: setNowPlayingStyleState,
        setAccentColor: setAccentColorState,
        setActiveTab: setActiveTabState,
        triggerRescan,
        isScanning
      }}
    >
      {children}
    </PlayerContext.Provider>
  );
};

export const usePlayer = () => {
  const context = useContext(PlayerContext);
  if (!context) throw new Error("usePlayer must be used inside a PlayerProvider");
  return context;
};
