/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { usePlayer } from "../context/PlayerContext";
import { Sliders, Headphones, Cpu, Sparkles, Volume2, HardDrive, RefreshCw, ArrowUpRight } from "lucide-react";
import { PARAMETRIC_FREQ_STAGES, BUILT_IN_PRESETS, BRAND_PROFILES } from "../utils/audioEngine";

export const EqualizerTab: React.FC = () => {
  const {
    dspEnabled,
    toggleDsp,
    eqGains,
    updateEqBand,
    applyPreset,
    exciterIntensity,
    updateExciter,
    stereoWidth,
    updateStereoWidth,
    compressorEnabled,
    updateCompressor,
    connectedDevice,
    connectDeviceProfile,
    disconnectDeviceProfile,
    dolbyAtmosMode,
    setDolbyMode,
    systemDolbyActive,
    accentColor
  } = usePlayer();

  const [activePresetId, setActivePresetId] = useState<string>("flat");

  // Format label helper
  const getFreqLabel = (f: number): string => {
    return f >= 1000 ? `${f / 1000}k` : `${f}`;
  };

  const handlePresetSelect = (id: string) => {
    setActivePresetId(id);
    applyPreset(id);
  };

  // SVG Bezier graph coordinates generator
  // We have 10 EQ bands from -12 to +12. We map them to an SVG coordinate space (e.g. width=600, height=120)
  const generateEqCurveYPoints = (): string => {
    const w = 560;
    const h = 120;
    const centerLine = h / 2;
    const padding = 20;
    
    const points = eqGains.map((gain, idx) => {
      // scale horizontal spacing
      const x = padding + (idx * (w - padding * 2)) / (eqGains.length - 1);
      // scale vertical gain (-12dB is bottom, +12dB is top)
      // Node coordinates has reversed Y in SVG
      const y = centerLine - (gain / 12) * (centerLine - 10);
      return { x, y };
    });

    if (points.length === 0) return "";

    // Plotte curve with quadratic Bezier anchors
    let path = `M ${points[0].x} ${points[0].y}`;
    for (let i = 0; i < points.length - 1; i++) {
      const p1 = points[i];
      const p2 = points[i + 1];
      const cpX = (p1.x + p2.x) / 2;
      path += ` C ${cpX} ${p1.y}, ${cpX} ${p2.y}, ${p2.x} ${p2.y}`;
    }
    return path;
  };

  return (
    <div className="flex flex-col gap-6 w-full animate-fade-in pb-4">
      
      {/* Title Header with style Outfit */}
      <div className="flex justify-between items-center bg-white/5 border border-white/5 p-4 rounded-2xl">
        <div className="text-left">
          <h1 className="text-3xl font-extrabold tracking-tight text-white/95 uppercase font-sans">
            Audio Center
          </h1>
          <p className="text-neutral-400 text-xs mt-1">
            Studio-grade lock-free float32 DSP processing, powered by AAudio / Web Audio.
          </p>
        </div>

        {/* Master ON/OFF toggle (top right) */}
        <div className="flex items-center gap-2.5">
          <span className="font-mono text-[9px] tracking-widest text-[#00D4FF] font-black uppercase" style={{ color: dspEnabled ? accentColor : undefined }}>
            {dspEnabled ? "DSP HIGH-PERF ONLINE" : "ACTIVE BYPASS"}
          </span>
          <button
            onClick={toggleDsp}
            className={`w-14 h-7 rounded-full px-1 flex items-center transition duration-300 cursor-pointer ${
              dspEnabled ? "bg-sky-500 justify-end" : "bg-neutral-800 justify-start"
            }`}
            style={{ backgroundColor: dspEnabled ? accentColor : undefined }}
          >
            <div className="w-5.5 h-5.5 rounded-full bg-neutral-950 border border-white/25 shadow-inner" />
          </button>
        </div>
      </div>

      {/* INTERACTIVE EQ BEZIER CURVE GRAPH */}
      <div className="p-4 rounded-2xl bg-black/60 border border-white/5 relative overflow-hidden flex flex-col gap-2">
        <div className="flex justify-between items-center text-[10px] font-mono tracking-widest text-neutral-400 font-bold uppercase mb-2 px-1">
          <span>Cascading 10-Band Parametric Graph</span>
          <span style={{ color: accentColor }}>±12dB Float Gain Stage</span>
        </div>

        <div className="relative h-28 w-full bg-[#0d0d15] rounded-xl overflow-hidden border border-white/5 shadow-inner flex items-center">
          {/* Horizontal Grid lines */}
          <div className="absolute inset-x-0 top-1/4 h-px border-t border-dashed border-white/5" />
          <div className="absolute inset-x-0 top-2/4 h-px border-t border-white/10" />
          <div className="absolute inset-x-0 top-3/4 h-px border-t border-dashed border-white/5" />

          {/* SVG bezier line representing eqGains */}
          <svg className="absolute inset-0 w-full h-full pointer-events-none">
            {dspEnabled && (
              <>
                {/* Under-curve color bleed gradient fill */}
                <path
                  d={`${generateEqCurveYPoints()} L 540 120 L 20 120 Z`}
                  fill={`url(#bleedGrad)`}
                  opacity="0.1"
                  className="transition-all duration-300"
                />
                
                {/* Thick glowing frequency wire */}
                <path
                  d={generateEqCurveYPoints()}
                  fill="none"
                  stroke={accentColor}
                  strokeWidth="3.5"
                  strokeLinecap="round"
                  className="transition-all duration-300"
                />
              </>
            )}

            {!dspEnabled && (
              <line x1="20" y1="60" x2="540" y2="60" stroke="rgba(255,255,255,0.15)" strokeWidth="2.5" />
            )}

            {/* Definitions */}
            <defs>
              <linearGradient id="bleedGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={accentColor} />
                <stop offset="100%" stopColor="transparent" />
              </linearGradient>
            </defs>
          </svg>

          {/* Draggable indicator nodes overlay */}
          <div className="absolute inset-x-0 inset-y-0 flex justify-between px-5 items-center pointer-events-none">
            {eqGains.map((gain, idx) => {
              // Coordinate height scaling
              const offsetPct = (gain / 12) * 50; // -50% to +50%
              return (
                <div 
                  key={idx} 
                  className="w-2.5 h-2.5 rounded-full bg-white/90 border border-neutral-900 shadow-xl transition-all duration-300 shrink-0"
                  style={{
                    transform: `translateY(${-offsetPct}px)`,
                    boxShadow: `0 0 12px ${accentColor}`
                  }}
                />
              );
            })}
          </div>
        </div>
      </div>

      {/* Preset pills selection */}
      <div className="flex gap-2 overflow-x-auto scrollbar-none py-1.5 px-0.5">
        {BUILT_IN_PRESETS.map((p) => {
          const isAct = activePresetId === p.id;
          return (
            <button
              key={p.id}
              onClick={() => handlePresetSelect(p.id)}
              className={`h-9 px-4 rounded-xl text-xs font-sans font-medium transition active:scale-95 ${
                isAct 
                  ? "bg-white text-neutral-950 font-bold" 
                  : "bg-white/5 border border-white/5 hover:bg-white/8 text-white/70"
              }`}
            >
              {p.name}
            </button>
          );
        })}
      </div>

      {/* 10 VERTICAL PARAMETRIC EQ SLIDERS */}
      <div className="p-5 rounded-2xl bg-[#12121A] border border-white/5 grid grid-cols-10 gap-x-2 gap-y-4 items-center justify-center">
        {eqGains.map((gain, idx) => {
          const freq = PARAMETRIC_FREQ_STAGES[idx];
          return (
            <div key={idx} className="flex flex-col items-center gap-3">
              {/* dB gain indicator banner */}
              <span className="font-mono text-[9px] text-white/40 font-bold leading-none h-3 select-none">
                {gain > 0 ? `+${gain}` : gain}
              </span>

              {/* Slider cylinder column */}
              <div className="h-40 md:h-44 w-7 flex items-center justify-center relative">
                {/* background groove cylinder track */}
                <div className="absolute w-1 h-full bg-black/60 rounded-full" />
                
                {/* Actual slider */}
                <input
                  type="range"
                  min="-12"
                  max="12"
                  step="0.5"
                  value={gain}
                  disabled={!dspEnabled}
                  onChange={(e) => updateEqBand(idx, parseFloat(e.target.value))}
                  className="vertical-slider h-full appearance-none bg-transparent cursor-ns-resize cursor-pointer z-10"
                  style={{
                    writingMode: "sideways-lr",
                    accentColor: accentColor
                  }}
                />
              </div>

              {/* Freq Label */}
              <span className="font-mono text-[10px] text-white/70 font-semibold leading-none text-center">
                {getFreqLabel(freq)}
              </span>
            </div>
          );
        })}
      </div>

      {/* ADVANCED PROCESSORS: Gain, Widener, Exciter, Compression, Dolby bypass */}
      <div className="grid grid-cols-12 gap-6 items-start">
        
        {/* Left Side: Advanced DSP Toggles Sliders */}
        <div className="col-span-12 md:col-span-7 p-5 rounded-2xl bg-white/5 border border-white/5 flex flex-col gap-4">
          <h3 className="font-sans font-bold text-xs uppercase tracking-widest text-[#00D4FF] mb-2 flex items-center gap-1" style={{ color: accentColor }}>
            <Cpu className="w-4 h-4" /> Professional Stage FX Parameters
          </h3>

          {/* Exciter Module */}
          <div className="flex flex-col gap-1.5 p-3 rounded-xl bg-black/30 border border-white/5">
            <div className="flex justify-between items-center text-[10px] font-sans font-extrabold text-white/80">
              <span className="uppercase tracking-wider">Harmonic Exciter (2nd/3rd Saturation)</span>
              <span className="font-mono text-[#00D4FF]" style={{ color: accentColor }}>{Math.round(exciterIntensity * 100)}% Saturation</span>
            </div>
            <input 
              type="range" 
              min="0" 
              max="1" 
              step="0.01" 
              value={exciterIntensity}
              disabled={!dspEnabled}
              onChange={(e) => updateExciter(parseFloat(e.target.value))}
              className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
              style={{ accentColor: accentColor }}
            />
            <p className="font-sans text-[9px] text-white/40 leading-normal">Excites harmonic sparkle into presence ranges, simulating valve hardware analog tubes.</p>
          </div>

          {/* Stereo Widener Haas Module */}
          <div className="flex flex-col gap-1.5 p-3 rounded-xl bg-black/30 border border-white/5">
            <div className="flex justify-between items-center text-[10px] font-sans font-extrabold text-white/80">
              <span className="uppercase tracking-wider">Haas Stereo Space Widener</span>
              <span className="font-mono text-[#7B61FF]">{Math.round(stereoWidth * 100)}% Width</span>
            </div>
            <input 
              type="range" 
              min="0" 
              max="1" 
              step="0.01" 
              value={stereoWidth}
              disabled={!dspEnabled}
              onChange={(e) => updateStereoWidth(parseFloat(e.target.value))}
              className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
              style={{ accentColor: "#7B61FF" }}
            />
            <p className="font-sans text-[9px] text-white/40 leading-normal">Splits channel timing arrays using Haas delay (15ms lag) to expand the stereo dynamic field.</p>
          </div>

          {/* Master Dynamic Range Compressor */}
          <div className="flex justify-between items-center bg-black/30 p-3.5 rounded-xl border border-white/5">
            <div className="text-left shrink max-w-[70%]">
              <span className="font-sans text-[10px] font-extrabold text-white/80 uppercase tracking-widest">Brickwall Dynamics Compressor</span>
              <p className="font-sans text-[9px] text-white/40 leading-normal mt-0.5">Limits peak outliers and pulls quiet details, leveling tracks to streaming standards.</p>
            </div>

            <button
              onClick={() => updateCompressor(!compressorEnabled)}
              disabled={!dspEnabled}
              className={`h-8 px-4 rounded-lg font-sans text-[10px] font-bold tracking-wider uppercase transition active:scale-95 ${
                compressorEnabled && dspEnabled
                  ? "bg-emerald-500/10 border border-emerald-400/20 text-emerald-300" 
                  : "bg-white/5 text-neutral-400 border border-white/5 opacity-50"
              }`}
            >
              {compressorEnabled ? "ONLINE" : "OFFLINE"}
            </button>
          </div>

        </div>

        {/* Right Side: Active Headwear Profile connectors */}
        <div className="col-span-12 md:col-span-5 p-5 rounded-2xl bg-white/5 border border-white/5 flex flex-col gap-3.5">
          <h3 className="font-sans font-bold text-xs uppercase tracking-widest text-[#FFD700] mb-2 flex items-center gap-1.5">
            <Headphones className="w-4 h-4" /> Active Device Autocalibrate
          </h3>

          {connectedDevice ? (
            <div className="p-4 rounded-xl bg-[#12121A] border border-sky-400/30 flex flex-col gap-2 animate-fade-in text-left">
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-[10px] font-mono tracking-widest uppercase font-bold text-sky-400" style={{ color: accentColor }}>{connectedDevice.brand} Connected</span>
                  <h4 className="font-sans font-bold text-sm text-white/90 truncate mt-0.5">{connectedDevice.deviceName}</h4>
                </div>
                <button
                  onClick={disconnectDeviceProfile}
                  className="font-mono text-[9px] text-rose-400 underline hover:text-rose-300 cursor-pointer"
                >
                  Disconnect
                </button>
              </div>

              <p className="font-sans text-[10px] leading-relaxed text-white/50 mt-1">
                Acoustic profiling is active. The 10 cascading filters have been computed layout to counter device capsule roll-offs. Codec preferenced to <strong className="font-mono text-white/80">{connectedDevice.codecPreference}</strong>.
              </p>

              <div className="flex gap-2 items-center text-[8px] font-mono tracking-widest text-emerald-400 bg-emerald-500/10 p-2 rounded-lg border border-emerald-400/20 uppercase font-black">
                <p>⚡ Sony Harman Counter Target Filter Calibration Online</p>
              </div>
            </div>
          ) : (
            <div className="flex flex-col gap-2">
              <p className="font-sans text-[10px] leading-relaxed text-white/40 text-left">
                Select your Bluetooth headwear below. Our acoustic DSP database will calibrate the parametric curve to neutralize its native roll-offs.
              </p>

              <div className="space-y-2 max-h-[160px] overflow-y-auto scrollbar-thin pr-1">
                {BRAND_PROFILES.map((p) => (
                  <div
                    key={p.brand}
                    className="p-2.5 rounded-xl bg-black/35 hover:bg-black/60 cursor-pointer border border-white/5 hover:border-[#00D4FF]/25 flex justify-between items-center transition"
                    onClick={() => connectDeviceProfile(p.brand)}
                  >
                    <div className="text-left truncate max-w-[80%]">
                      <p className="font-sans text-xs font-bold text-white/90 truncate">{p.deviceName}</p>
                      <p className="font-sans text-[9px] text-white/40 truncate mt-0.5">{p.description}</p>
                    </div>
                    <ArrowUpRight className="w-3.5 h-3.5 text-neutral-500 hover:text-white" />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* System Dolby conflict bypass check block */}
          <div className="p-3 rounded-xl bg-black/40 border border-white/5 text-left flex flex-col gap-1.5">
            <span className="font-sans text-[9px] font-bold text-[#FF2D87] uppercase tracking-widest">Dolby Atmos Override Compatibility</span>
            <p className="font-sans text-[9px] leading-normal text-white/40">
              When Android system Dolby/Dirac engines are active, we autoadjust spatial delay matrices and compressor weights to avoid compound audio distortion.
            </p>
            
            <div className="flex justify-between items-center mt-1">
              <span className="font-mono text-[9px] text-neutral-400">Atmos bypass conflict policy:</span>
              <select 
                value={dolbyAtmosMode}
                onChange={(e: any) => setDolbyMode(e.target.value)}
                className="h-6 rounded bg-[#101017] border border-white/10 text-[9px] font-mono text-white max-w-[120px] focus:outline-none focus:border-sky-400"
              >
                <option value="auto">Auto-negotiate</option>
                <option value="bypass">Force Bypass</option>
                <option value="active">Permissive DSP</option>
              </select>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
