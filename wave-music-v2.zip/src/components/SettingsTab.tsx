import React, { useState } from "react";
import { usePlayer } from "../context/PlayerContext";
import { Palette, Music, Cpu, Bluetooth, Download, Info, ChevronRight, Moon, Sun, Zap, Volume2, RefreshCw } from "lucide-react";

const ACCENT_COLORS = ["#00D4FF","#7B61FF","#FF2D87","#39FF14","#FFD700","#FF6B35","#00FF88","#FF1744"];
const SECTIONS = ["Appearance","Library","Playback","Audio DSP","Bluetooth","Codecs","About"] as const;
type Section = typeof SECTIONS[number];

export const SettingsTab: React.FC = () => {
  const { accentColor, setAccentColor, codecDownloads, downloadCodec, tracks,
    isScanning, triggerRescan, dspEnabled, toggleDsp, connectedDevice,
    connectDeviceProfile, disconnectDeviceProfile, systemDolbyActive, dolbyAtmosMode, setDolbyMode } = usePlayer();

  const [section, setSection] = useState<Section>("Appearance");
  const [theme, setTheme] = useState<"amoled"|"dark"|"light">("amoled");
  const [nowPlayingStyle, setNowPlayingStyle] = useState<"immersive"|"minimal">("immersive");
  const [gapless, setGapless] = useState(true);
  const [backgroundPlay, setBackgroundPlay] = useState(true);
  const [crossfade, setCrossfade] = useState(3);
  const [lufsTarget, setLufsTarget] = useState(-14);
  const [showArtAnim, setShowArtAnim] = useState(true);
  const [autoLike, setAutoLike] = useState(false);
  const [btBrand, setBtBrand] = useState("");

  const Toggle = ({ value, onToggle }: { value: boolean; onToggle: () => void }) => (
    <button onClick={onToggle}
      className={`w-12 h-6 rounded-full transition-all flex items-center px-0.5 ${value ? "justify-end" : "justify-start bg-white/15"}`}
      style={value ? { background: accentColor } : {}}>
      <div className="w-5 h-5 rounded-full bg-white shadow" />
    </button>
  );

  const Row = ({ label, sub, children }: { label: string; sub?: string; children: React.ReactNode }) => (
    <div className="flex items-center justify-between py-3.5 border-b border-white/6">
      <div>
        <p className="text-sm text-white/85 font-medium">{label}</p>
        {sub && <p className="text-xs text-white/35 mt-0.5">{sub}</p>}
      </div>
      <div className="ml-4 flex-shrink-0">{children}</div>
    </div>
  );

  const renderSection = () => {
    switch (section) {
      case "Appearance":
        return (
          <div>
            <Row label="Theme">
              <div className="flex gap-1">
                {(["amoled","dark"] as const).map(t => (
                  <button key={t} onClick={() => setTheme(t)}
                    className={`px-3 py-1 rounded-full text-xs font-bold transition-all ${theme === t ? "text-black" : "bg-white/8 text-white/50"}`}
                    style={theme === t ? { background: accentColor } : {}}>
                    {t === "amoled" ? "AMOLED" : "Dark"}
                  </button>
                ))}
              </div>
            </Row>
            <Row label="Accent Color" sub="Extracted from album art or fixed">
              <div className="flex gap-1.5 flex-wrap justify-end max-w-[160px]">
                {ACCENT_COLORS.map(c => (
                  <button key={c} onClick={() => setAccentColor(c)}
                    className={`w-6 h-6 rounded-full border-2 transition-all active:scale-90 ${accentColor === c ? "border-white scale-110" : "border-transparent"}`}
                    style={{ background: c }} />
                ))}
              </div>
            </Row>
            <Row label="Now Playing Style">
              <div className="flex gap-1">
                {(["immersive","minimal"] as const).map(s => (
                  <button key={s} onClick={() => setNowPlayingStyle(s)}
                    className={`px-3 py-1 rounded-full text-xs font-bold transition-all capitalize ${nowPlayingStyle === s ? "text-black" : "bg-white/8 text-white/50"}`}
                    style={nowPlayingStyle === s ? { background: accentColor } : {}}>{s}</button>
                ))}
              </div>
            </Row>
            <Row label="Disc Rotation Animation" sub="Album art spins during playback">
              <Toggle value={showArtAnim} onToggle={() => setShowArtAnim(!showArtAnim)} />
            </Row>
          </div>
        );

      case "Library":
        return (
          <div>
            <div className="p-4 mb-3 rounded-2xl bg-white/5 border border-white/8">
              <p className="text-sm text-white/60 mb-1">{tracks.length} tracks in library</p>
              <p className="text-xs text-white/30">Add music using the Upload button in Library tab. Select multiple files at once.</p>
            </div>
            <Row label="Rescan Library" sub="Re-index all added tracks">
              <button onClick={triggerRescan}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold border border-white/15 text-white/70 active:scale-95 ${isScanning ? "animate-pulse" : ""}`}>
                <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? "animate-spin" : ""}`} />
                {isScanning ? "Scanning…" : "Rescan"}
              </button>
            </Row>
            <Row label="Auto-like on 5 plays" sub="Automatically heart frequently played tracks">
              <Toggle value={autoLike} onToggle={() => setAutoLike(!autoLike)} />
            </Row>
            <div className="mt-4 p-4 rounded-2xl bg-amber-500/8 border border-amber-500/20">
              <p className="text-xs font-bold text-amber-400 mb-1">📱 Android File Access</p>
              <p className="text-xs text-white/40 leading-relaxed">To scan your full music library automatically, the native Android version (built from the full Kotlin prompt) is required. This web version supports manual file adding only.</p>
            </div>
          </div>
        );

      case "Playback":
        return (
          <div>
            <Row label="Background Playback" sub="Continue playing when app is minimized">
              <Toggle value={backgroundPlay} onToggle={() => setBackgroundPlay(!backgroundPlay)} />
            </Row>
            <Row label="Gapless Playback" sub="No silence between tracks">
              <Toggle value={gapless} onToggle={() => setGapless(!gapless)} />
            </Row>
            <Row label={`Crossfade: ${crossfade}s`} sub="Overlap between consecutive tracks">
              <input type="range" min="0" max="12" step="1" value={crossfade}
                onChange={e => setCrossfade(parseInt(e.target.value))}
                className="w-28 h-1 rounded-full appearance-none cursor-pointer bg-white/15"
                style={{ accentColor }} />
            </Row>
            <div className="mt-4 p-4 rounded-2xl bg-white/5 border border-white/8">
              <p className="text-xs font-bold text-white/50 mb-2 uppercase tracking-wider">Notification & Lock Screen</p>
              <p className="text-xs text-white/35 leading-relaxed">Media controls appear in your notification bar and lock screen automatically when a track is playing. This is handled by Android's MediaSession API in the native build.</p>
            </div>
          </div>
        );

      case "Audio DSP":
        return (
          <div>
            <Row label="DSP Engine" sub="10-band EQ + exciter + compressor">
              <Toggle value={dspEnabled} onToggle={toggleDsp} />
            </Row>
            <Row label={`Loudness Target: ${lufsTarget} LUFS`} sub="ITU-R BS.1770-4 normalization">
              <input type="range" min="-18" max="-9" step="1" value={lufsTarget}
                onChange={e => setLufsTarget(parseInt(e.target.value))}
                className="w-28 h-1 rounded-full appearance-none cursor-pointer bg-white/15"
                style={{ accentColor }} />
            </Row>
            <Row label="Dolby Atmos Mode" sub="Conflict resolution with system DSP">
              <div className="flex gap-1">
                {(["auto","bypass","active"] as const).map(m => (
                  <button key={m} onClick={() => setDolbyMode(m)}
                    className={`px-2 py-1 rounded-lg text-[10px] font-bold capitalize transition-all ${dolbyAtmosMode === m ? "text-black" : "bg-white/8 text-white/40"}`}
                    style={dolbyAtmosMode === m ? { background: accentColor } : {}}>{m}</button>
                ))}
              </div>
            </Row>
            {systemDolbyActive && (
              <div className="mt-3 p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20">
                <p className="text-xs text-cyan-400">⚡ Dolby Atmos detected — Stereo widener, compressor and exciter auto-disabled to prevent double processing.</p>
              </div>
            )}
          </div>
        );

      case "Bluetooth":
        return (
          <div>
            {connectedDevice ? (
              <div className="p-4 mb-4 rounded-2xl border" style={{ background: `${accentColor}15`, borderColor: `${accentColor}40` }}>
                <p className="text-sm font-bold text-white/90">🎧 {connectedDevice.deviceName}</p>
                <p className="text-xs text-white/45 mt-1">Brand profile: {connectedDevice.brand} · {connectedDevice.codecPreference}</p>
                <button onClick={disconnectDeviceProfile} className="mt-3 text-xs text-red-400 font-semibold">Disconnect profile</button>
              </div>
            ) : (
              <div className="p-4 mb-4 rounded-2xl bg-white/5 border border-white/8 text-xs text-white/40">No device profile active. Simulate one below.</div>
            )}
            <p className="text-xs text-white/35 mb-3 px-1">Simulate a brand EQ profile (auto-applied on real Bluetooth connect):</p>
            <div className="flex flex-wrap gap-2">
              {["SONY","SAMSUNG","JBL","BOSE","SENNHEISER","JVC","JABRA","APPLE","ANKER"].map(brand => (
                <button key={brand} onClick={() => connectDeviceProfile(brand)}
                  className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all active:scale-90 ${connectedDevice?.brand === brand ? "text-black border-transparent" : "bg-white/5 border-white/10 text-white/60"}`}
                  style={connectedDevice?.brand === brand ? { background: accentColor } : {}}>
                  {brand}
                </button>
              ))}
            </div>
          </div>
        );

      case "Codecs":
        return (
          <div className="space-y-2">
            {codecDownloads.map(codec => (
              <div key={codec.id} className="p-4 rounded-2xl bg-white/5 border border-white/8 flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 ${codec.isDownloaded ? "bg-green-500/20" : "bg-white/5"}`}>
                  <Download className={`w-4 h-4 ${codec.isDownloaded ? "text-green-400" : "text-white/30"}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-white/85 truncate">{codec.name}</p>
                  <p className="text-xs text-white/35">{codec.desc} · {codec.size}</p>
                </div>
                {!codec.isDownloaded && (
                  <button onClick={() => downloadCodec(codec.id)}
                    className="px-3 py-1.5 rounded-xl text-xs font-bold text-black flex-shrink-0"
                    style={{ background: accentColor }}>Get</button>
                )}
                {codec.isDownloaded && <span className="text-xs text-green-400 font-bold flex-shrink-0">✓</span>}
              </div>
            ))}
          </div>
        );

      case "About":
        return (
          <div className="space-y-3 text-sm">
            <div className="p-5 rounded-2xl bg-white/5 border border-white/8 text-center">
              <div className="w-16 h-16 rounded-2xl mx-auto mb-3 flex items-center justify-center" style={{ background: `linear-gradient(135deg, ${accentColor}, #7B61FF)` }}>
                <Music className="w-8 h-8 text-white" />
              </div>
              <p className="font-black text-white text-lg">Liquid Glass Wave</p>
              <p className="text-white/40 text-xs mt-1">Version 1.0.0 · React + Capacitor</p>
            </div>
            <div className="p-4 rounded-2xl bg-white/5 border border-white/8">
              <p className="text-xs text-white/40 leading-relaxed">Built with React, Web Audio API, Capacitor. For full native performance including auto library scanning, lock screen controls, and background playback, use the native Kotlin build from the full prompt.</p>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="flex flex-col h-full">
      <div className="px-5 pt-5 pb-4">
        <h1 className="text-2xl font-extrabold text-white">Settings</h1>
      </div>

      {/* Section pills */}
      <div className="flex overflow-x-auto gap-2 px-5 pb-3 scrollbar-none">
        {SECTIONS.map(s => (
          <button key={s} onClick={() => setSection(s)}
            className={`px-4 h-8 rounded-full text-xs font-bold whitespace-nowrap border flex-shrink-0 transition-all ${section === s ? "text-black border-transparent" : "bg-white/6 border-white/8 text-white/50"}`}
            style={section === s ? { background: accentColor } : {}}>
            {s}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-8">
        {renderSection()}
      </div>
    </div>
  );
};
