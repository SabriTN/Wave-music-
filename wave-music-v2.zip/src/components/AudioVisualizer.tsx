/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect } from "react";
import { usePlayer } from "../context/PlayerContext";
import { VisualizerMode } from "../types";
import { engine } from "../utils/audioEngine";

export const AudioVisualizer: React.FC = () => {
  const { visualizerMode, accentColor, isPlaying } = usePlayer();
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationRef = useRef<number | null>(null);
  const particlesRef = useRef<{ x: number; y: number; vx: number; vy: number; radius: number; alpha: number }[]>([]);

  // Initialize simulated particles
  useEffect(() => {
    const list = [];
    for (let i = 0; i < 40; i++) {
      list.push({
        x: Math.random() * 300,
        y: Math.random() * 200,
        vx: (Math.random() - 0.5) * 1.5,
        vy: (Math.random() - 0.5) * 1.5,
        radius: Math.random() * 3 + 1,
        alpha: Math.random() * 0.5 + 0.3
      });
    }
    particlesRef.current = list;
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const resizeCanvas = () => {
      canvas.width = canvas.parentElement?.clientWidth || 350;
      canvas.height = canvas.parentElement?.clientHeight || 200;
    };
    resizeCanvas();

    // Use ResizeObserver for responsive canvas scaling
    const obs = new ResizeObserver(() => {
      resizeCanvas();
    });
    if (canvas.parentElement) {
      obs.observe(canvas.parentElement);
    }

    const analyser = engine.analyserNode;
    const bufferLength = analyser ? analyser.frequencyBinCount : 128;
    const dataArray = new Uint8Array(bufferLength);
    const timeDomainArray = new Uint8Array(bufferLength);

    let offsetSim = 0; // fallback wave phase simulation

    const render = () => {
      animationRef.current = requestAnimationFrame(render);

      const w = canvas.width;
      const h = canvas.height;

      // Clear with dark chromatic backdrop
      ctx.fillStyle = "rgba(10, 10, 15, 0.22)"; // slight trail effect
      ctx.fillRect(0, 0, w, h);

      offsetSim += 0.05;

      // Determine active frequency bytes
      if (analyser && isPlaying) {
        analyser.getByteFrequencyData(dataArray);
        analyser.getByteTimeDomainData(timeDomainArray);
      } else {
        // Fallback procedural visualizer data when idle/bypassed
        for (let i = 0; i < bufferLength; i++) {
          const mult = isPlaying ? 1.5 : 0.2;
          dataArray[i] = Math.max(10, 30 + Math.sin(i * 0.15 + offsetSim) * 20 * mult + Math.cos(i * 0.05 - offsetSim) * 10 * mult);
          timeDomainArray[i] = 128 + Math.sin(i * 0.12 + offsetSim) * 30 * mult;
        }
      }

      // Read bass intensity
      let bassSum = 0;
      const bassRange = Math.min(6, bufferLength);
      for (let i = 0; i < bassRange; i++) {
        bassSum += dataArray[i];
      }
      const bassIntensity = (bassSum / bassRange) / 255.0; // 0 to 1

      // Render based on user preference
      if (visualizerMode === VisualizerMode.SPECTRUM) {
        // Render 32 glowing equalizer spectrum columns
        const barCount = 32;
        const barWidth = (w / barCount) - 2;
        
        for (let i = 0; i < barCount; i++) {
          const dIdx = Math.floor(i * (bufferLength / barCount) * 0.7); // focus on low-mid freq
          const rawVal = dataArray[dIdx] || 0;
          const barHeight = (rawVal / 255) * h * 0.85 + 5;

          const x = i * (barWidth + 2);
          const y = h - barHeight;

          // Drawing glowing gradient pillar
          const grad = ctx.createLinearGradient(x, y, x, h);
          grad.addColorStop(0, accentColor);
          grad.addColorStop(0.5, "rgba(123, 97, 255, 0.7)");
          grad.addColorStop(1, "rgba(0, 212, 255, 0.05)");

          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.roundRect(x, y, barWidth, barHeight, [4, 4, 0, 0]);
          ctx.fill();

          // Top peak particle dot
          ctx.fillStyle = "rgba(255, 255, 255, 0.7)";
          ctx.fillRect(x, Math.max(0, y - 3), barWidth, 2);
        }

      } else if (visualizerMode === VisualizerMode.WAVEFORM) {
        // Render oscilloscope neon string
        ctx.lineWidth = 3;
        ctx.strokeStyle = accentColor;
        ctx.shadowBlur = 10;
        ctx.shadowColor = accentColor;

        ctx.beginPath();
        const sliceWidth = w / bufferLength;
        let x = 0;

        for (let i = 0; i < bufferLength; i++) {
          const v = timeDomainArray[i] / 128.0;
          const y = (v * h) / 2;

          if (i === 0) {
            ctx.moveTo(x, y);
          } else {
            ctx.lineTo(x, y);
          }
          x += sliceWidth;
        }

        ctx.lineTo(w, h / 2);
        ctx.stroke();
        
        // Reset shadow
        ctx.shadowBlur = 0;

      } else if (visualizerMode === VisualizerMode.CIRCULAR) {
        // Render radial glowing spikes framing a cylinder
        const cx = w / 2;
        const cy = h / 2;
        const baseRadius = Math.min(w, h) * 0.28 + (bassIntensity * 15);
        const spikeCount = 64;

        ctx.strokeStyle = accentColor;
        ctx.lineWidth = 2.5;

        for (let i = 0; i < spikeCount; i++) {
          const angle = (i / spikeCount) * Math.PI * 2;
          const dataIdx = Math.floor(i * (bufferLength / spikeCount) * 0.5);
          const val = dataArray[dataIdx] || 0;
          const spikeLen = (val / 255.0) * h * 0.25;

          const x1 = cx + Math.cos(angle) * baseRadius;
          const y1 = cy + Math.sin(angle) * baseRadius;
          const x2 = cx + Math.cos(angle) * (baseRadius + spikeLen);
          const y2 = cy + Math.sin(angle) * (baseRadius + spikeLen);

          const radGrad = ctx.createLinearGradient(x1, y1, x2, y2);
          radGrad.addColorStop(0, "rgba(255, 255, 255, 0.2)");
          radGrad.addColorStop(0.3, accentColor);
          radGrad.addColorStop(1, "rgba(123, 97, 255, 0.05)");

          ctx.strokeStyle = radGrad;
          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.stroke();
        }

        // Draw inner chrome ring
        ctx.strokeStyle = "rgba(255, 255, 255, 0.12)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(cx, cy, baseRadius, 0, Math.PI * 2);
        ctx.stroke();

      } else if (visualizerMode === VisualizerMode.PARTICLES) {
        // Render spatial coordinates triggered by bass nodes
        const particles = particlesRef.current;
        const cx = w / 2;
        const cy = h / 2;

        particles.forEach((p, idx) => {
          // Adjust velocity based on sub bass power
          const speedFactor = 1.0 + (bassIntensity * 4.0);
          p.x += p.vx * speedFactor;
          p.y += p.vy * speedFactor;

          // Boundary bounce
          if (p.x < 0 || p.x > w) p.vx *= -1;
          if (p.y < 0 || p.y > h) p.vy *= -1;

          // Draw orbital dust trailing accent color
          ctx.fillStyle = accentColor;
          ctx.shadowBlur = bassIntensity * 20;
          ctx.shadowColor = accentColor;
          
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius * (1.0 + bassIntensity * 1.5), 0, Math.PI * 2);
          ctx.fill();
        });

        // Clear shadow
        ctx.shadowBlur = 0;
      }
    };

    render();

    return () => {
      obs.disconnect();
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [visualizerMode, accentColor, isPlaying]);

  return (
    <div className="relative w-full h-full rounded-2xl overflow-hidden bg-gradient-to-b from-[#0e0e15] to-[#040408] border border-white/5 active:scale-98 transition duration-200 cursor-pointer">
      <canvas id="canvas-spectrometer" ref={canvasRef} className="absolute inset-0 w-full h-full" />
      <div className="absolute top-3 left-4 flex gap-1.5 items-center pointer-events-none">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
        <span className="font-mono text-[9px] tracking-widest text-neutral-400 font-bold uppercase">
          {visualizerMode} Core Engine Connected
        </span>
      </div>
      {isPlaying && (
        <div className="absolute bottom-3 right-4 font-mono text-[9px] tracking-wide text-white/40 pointer-events-none">
          32-Band FFT Node Direct
        </div>
      )}
    </div>
  );
};
