import React, { useState, useRef } from "react";
import { usePlayer } from "../context/PlayerContext";
import { Play, Heart, UploadCloud, Music, Search, FolderOpen, RefreshCw, Plus, Trash2 } from "lucide-react";
import { formatTime } from "../utils/time";

export const LibraryTab: React.FC = () => {
  const {
    tracks, playTrack, currentTrack, isPlaying, toggleLikeTrack, likedTrackIds,
    addNewTrack, playlists, createPlaylist, accentColor, triggerRescan, isScanning, setActiveTab
  } = usePlayer();

  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [activeSection, setActiveSection] = useState<"tracks"|"playlists">("tracks");
  const [newPLName, setNewPLName] = useState("");
  const [showNewPL, setShowNewPL] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const multiFileRef = useRef<HTMLInputElement>(null);

  // Handle multiple file upload (bulk add)
  const handleFiles = (files: FileList | null) => {
    if (!files) return;
    Array.from(files).forEach(file => {
      if (file.type.startsWith("audio/") || /\.(mp3|wav|flac|ogg|aac|m4a|opus)$/i.test(file.name)) {
        addNewTrack(file);
      }
    });
  };

  const filtered = tracks.filter(t => {
    const q = search.toLowerCase();
    const matchSearch = !q || t.title.toLowerCase().includes(q) || t.artist.toLowerCase().includes(q) || t.album.toLowerCase().includes(q);
    if (!matchSearch) return false;
    if (filter === "favorites") return likedTrackIds.includes(t.id);
    if (filter === "local") return t.id.startsWith("dropped_") || t.id.startsWith("stream_");
    return true;
  });

  return (
    <div className="flex flex-col h-full gap-0 pb-24">

      {/* Header */}
      <div className="px-5 pt-5 pb-3">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-extrabold text-white tracking-tight">Your Music</h1>
          <div className="flex gap-2">
            {/* Bulk scan / add multiple */}
            <button onClick={() => multiFileRef.current?.click()}
              className="w-9 h-9 rounded-full bg-white/8 flex items-center justify-center active:scale-90 border border-white/10"
              title="Add multiple files">
              <UploadCloud className="w-4 h-4 text-white/60" />
            </button>
            {/* Rescan */}
            <button onClick={triggerRescan}
              className={`w-9 h-9 rounded-full bg-white/8 flex items-center justify-center active:scale-90 border border-white/10 ${isScanning ? "animate-spin" : ""}`}
              title="Rescan library">
              <RefreshCw className="w-4 h-4 text-white/60" />
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="flex items-center gap-2 bg-white/8 border border-white/10 rounded-2xl px-4 h-11 mb-3">
          <Search className="w-4 h-4 text-white/35 flex-shrink-0" />
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search tracks, artists, albums…"
            className="flex-1 bg-transparent text-sm text-white placeholder-white/25 outline-none" />
        </div>

        {/* Filter chips */}
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-none">
          {["all","favorites","local"].map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className={`px-4 h-8 rounded-full text-xs font-bold whitespace-nowrap border transition-all flex-shrink-0 ${filter === f ? "border-transparent text-black" : "bg-white/6 border-white/10 text-white/50"}`}
              style={filter === f ? { background: accentColor } : {}}>
              {f === "all" ? "All Tracks" : f === "favorites" ? "❤️ Liked" : "📁 Added"}
            </button>
          ))}
        </div>
      </div>

      {/* Section tabs */}
      <div className="flex px-5 gap-4 border-b border-white/8 mb-1">
        {(["tracks","playlists"] as const).map(s => (
          <button key={s} onClick={() => setActiveSection(s)}
            className={`pb-2 text-sm font-bold capitalize border-b-2 transition-all ${activeSection === s ? "border-current text-white" : "border-transparent text-white/35"}`}
            style={{ borderColor: activeSection === s ? accentColor : undefined, color: activeSection === s ? accentColor : undefined }}>
            {s === "tracks" ? `Tracks (${filtered.length})` : `Playlists (${playlists.length})`}
          </button>
        ))}
      </div>

      {activeSection === "tracks" ? (
        <div className="flex-1 overflow-y-auto">
          {/* Scan notice */}
          {isScanning && (
            <div className="mx-5 my-3 p-3 rounded-xl bg-white/5 border border-white/10 text-xs text-white/50 text-center animate-pulse">
              🔍 Scanning for music files…
            </div>
          )}

          {/* Upload area — prominent when library is small */}
          {tracks.length <= 4 && (
            <div onClick={() => multiFileRef.current?.click()}
              className="mx-5 my-3 p-5 rounded-2xl border-2 border-dashed border-white/15 flex flex-col items-center gap-2 cursor-pointer active:bg-white/5">
              <FolderOpen className="w-8 h-8 text-white/25" />
              <p className="text-sm font-semibold text-white/50">Tap to add music files</p>
              <p className="text-xs text-white/25 text-center">MP3, FLAC, WAV, AAC, OGG and more<br/>Select multiple files at once</p>
            </div>
          )}

          {filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 gap-3 text-center px-8">
              <Music className="w-12 h-12 text-white/15" />
              <p className="text-white/35 text-sm">{search ? "No results found" : "No tracks yet"}</p>
              {!search && <button onClick={() => multiFileRef.current?.click()}
                className="px-5 py-2 rounded-full text-sm font-bold text-black mt-2"
                style={{ background: accentColor }}>Add Music</button>}
            </div>
          ) : (
            filtered.map((track) => {
              const isCurr = currentTrack?.id === track.id;
              const isLiked = likedTrackIds.includes(track.id);
              return (
                <div key={track.id}
                  className={`flex items-center gap-3 px-5 py-3 border-b border-white/4 active:bg-white/5 cursor-pointer transition-colors ${isCurr ? "bg-white/6" : ""}`}
                  onClick={() => { playTrack(track); setActiveTab("nowplaying"); }}>
                  <div className="relative flex-shrink-0">
                    <img src={track.albumArtUri} alt="" className="w-12 h-12 rounded-xl object-cover" />
                    {isCurr && isPlaying && (
                      <div className="absolute inset-0 rounded-xl flex items-center justify-center bg-black/50">
                        <div className="flex gap-0.5 items-end h-4">
                          {[1,2,3].map(i => <div key={i} className="w-1 rounded-full animate-bounce" style={{ background: accentColor, height: `${i*4+4}px`, animationDelay: `${i*0.1}s` }} />)}
                        </div>
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-semibold truncate ${isCurr ? "text-white" : "text-white/85"}`}
                      style={{ color: isCurr ? accentColor : undefined }}>{track.title}</p>
                    <p className="text-xs text-white/40 truncate">{track.artist} · <span className="font-mono">{track.format}</span></p>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <span className="text-xs text-white/25 font-mono">{formatTime(track.duration)}</span>
                    <button onClick={e => { e.stopPropagation(); toggleLikeTrack(track.id); }}
                      className="w-8 h-8 rounded-full flex items-center justify-center active:scale-90">
                      <Heart className={`w-4 h-4 ${isLiked ? "fill-[#FF2D87] stroke-[#FF2D87]" : "stroke-white/25"}`} />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto px-5 pt-3">
          <button onClick={() => setShowNewPL(true)}
            className="w-full mb-3 py-3 rounded-2xl border border-dashed border-white/15 flex items-center justify-center gap-2 text-sm text-white/40 active:bg-white/5">
            <Plus className="w-4 h-4" /> New Playlist
          </button>
          {showNewPL && (
            <div className="mb-3 p-4 rounded-2xl bg-white/5 border border-white/10 flex gap-2">
              <input value={newPLName} onChange={e => setNewPLName(e.target.value)}
                placeholder="Playlist name…" className="flex-1 bg-transparent text-sm text-white outline-none placeholder-white/25" />
              <button onClick={() => { if (newPLName.trim()) { createPlaylist(newPLName.trim()); setNewPLName(""); setShowNewPL(false); } }}
                className="px-3 py-1 rounded-xl text-xs font-bold text-black"
                style={{ background: accentColor }}>Create</button>
            </div>
          )}
          {playlists.map(pl => (
            <div key={pl.id} className="flex items-center gap-3 p-4 rounded-2xl bg-white/5 border border-white/8 mb-2 active:bg-white/8 cursor-pointer">
              <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${accentColor}22` }}>
                <Music className="w-5 h-5" style={{ color: accentColor }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-white/90 truncate">{pl.name}</p>
                <p className="text-xs text-white/35">{pl.songs.length} tracks {pl.isSmart ? "· Smart" : ""}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Hidden file inputs */}
      <input ref={fileInputRef} type="file" accept="audio/*" className="hidden" onChange={e => handleFiles(e.target.files)} />
      <input ref={multiFileRef} type="file" accept="audio/*" multiple className="hidden" onChange={e => handleFiles(e.target.files)} />
    </div>
  );
};
