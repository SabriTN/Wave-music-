import React, { useRef, useEffect, useState, useCallback } from "react";
import { usePlayer } from "../context/PlayerContext";
import { Play, Pause, SkipForward, SkipBack, Shuffle, Repeat, Heart, Volume2, ListMusic, X, ChevronDown, Music } from "lucide-react";
import { formatTime } from "../utils/time";

export const NowPlayingTab: React.FC = () => {
  const {
    currentTrack, isPlaying, currentTime, duration, togglePlay, seekTo,
    volume, setVolume, nextTrack, prevTrack, isShuffleOn, toggleShuffle,
    repeatMode, toggleRepeat, toggleLikeTrack, likedTrackIds, accentColor,
    currentLyricText, currentLyricIndex, queue, dspEnabled, toggleDsp,
    connectedDevice, setActiveTab
  } = usePlayer();

  const [isQueueOpen, setIsQueueOpen] = useState(false);
  const [showLyrics, setShowLyrics] = useState(false);
  const [showFullArt, setShowFullArt] = useState(false);
  const [doubleTapTimer, setDoubleTapTimer] = useState<ReturnType<typeof setTimeout> | null>(null);
  const seekRef = useRef<HTMLDivElement>(null);
  const lyricsRef = useRef<HTMLDivElement>(null);
  const isDragging = useRef(false);

  // Auto-scroll lyrics
  useEffect(() => {
    if (lyricsRef.current) {
      const active = lyricsRef.current.querySelector('[data-active="true"]');
      if (active) active.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }, [currentLyricIndex]);

  // Seekbar drag
  const handleSeek = useCallback((e: React.MouseEvent | React.TouchEvent) => {
    if (!seekRef.current || duration === 0) return;
    const rect = seekRef.current.getBoundingClientRect();
    const clientX = "touches" in e ? e.touches[0].clientX : e.clientX;
    const pct = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
    seekTo(pct * duration);
  }, [duration, seekTo]);

  // Double tap on album art → show lyrics
  const handleArtTap = () => {
    if (doubleTapTimer) {
      clearTimeout(doubleTapTimer);
      setDoubleTapTimer(null);
      setShowLyrics(true);
    } else {
      const t = setTimeout(() => {
        setShowFullArt(true);
        setDoubleTapTimer(null);
      }, 280);
      setDoubleTapTimer(t);
    }
  };

  const progressPct = duration > 0 ? (currentTime / duration) * 100 : 0;
  const isLiked = currentTrack ? likedTrackIds.includes(currentTrack.id) : false;

  if (!currentTrack) {
    return (
      <div className="flex flex-col items-center justify-center h-full min-h-[60vh] gap-4 text-center px-8">
        <div className="w-24 h-24 rounded-full bg-white/5 flex items-center justify-center mb-2">
          <Music className="w-10 h-10 text-white/20" />
        </div>
        <p className="text-white/50 text-sm">No track selected</p>
        <button onClick={() => setActiveTab("home")}
          className="px-6 py-2.5 rounded-full text-sm font-semibold text-black"
          style={{ background: accentColor }}>
          Browse Library
        </button>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full relative select-none">

      {/* Full blur bg from album art */}
      <div className="absolute inset-0 z-0 overflow-hidden rounded-3xl">
        <img src={currentTrack.albumArtUri} alt="" className="w-full h-full object-cover scale-110 blur-[60px] opacity-40" />
        <div className="absolute inset-0 bg-[#0A0A0F]/80" />
      </div>

      <div className="relative z-10 flex flex-col h-full px-5 pt-4 pb-2 gap-3">

        {/* Top bar */}
        <div className="flex items-center justify-between">
          <button onClick={() => setActiveTab("home")} className="w-9 h-9 rounded-full bg-white/8 flex items-center justify-center active:scale-90">
            <ChevronDown className="w-5 h-5 text-white/70" />
          </button>
          <span className="text-xs font-bold uppercase tracking-widest text-white/40">Now Playing</span>
          <button onClick={() => setIsQueueOpen(true)} className="w-9 h-9 rounded-full bg-white/8 flex items-center justify-center active:scale-90">
            <ListMusic className="w-4 h-4 text-white/70" />
          </button>
        </div>

        {/* Album Art — tap for fullscreen, double-tap for lyrics */}
        <div className="flex justify-center mt-1">
          <div
            onClick={handleArtTap}
            className="relative cursor-pointer active:scale-95 transition-transform duration-200"
            style={{ width: "72vw", maxWidth: 280, height: "72vw", maxHeight: 280 }}
          >
            <div className="absolute inset-0 rounded-2xl blur-[28px] opacity-50 scale-95" style={{ background: accentColor }} />
            <img
              src={currentTrack.albumArtUri}
              alt={currentTrack.title}
              className={`relative w-full h-full object-cover rounded-2xl border border-white/10 shadow-2xl ${isPlaying ? "animate-[spin_30s_linear_infinite]" : ""}`}
              style={{ borderRadius: "50%" }}
            />
            {/* Center hole */}
            <div className="absolute inset-0 m-auto w-10 h-10 rounded-full bg-[#0A0A0F] border-2 border-white/15 pointer-events-none" style={{ top: "50%", left: "50%", transform: "translate(-50%,-50%)", position: "absolute" }} />
            <p className="absolute bottom-2 left-0 right-0 text-center text-[9px] text-white/30 font-mono">
              Double-tap for lyrics
            </p>
          </div>
        </div>

        {/* Track info + like */}
        <div className="flex items-center justify-between px-1 mt-1">
          <div className="flex-1 min-w-0 mr-3">
            <p className="text-white font-bold text-lg truncate leading-tight">{currentTrack.title}</p>
            <p className="text-white/45 text-sm truncate mt-0.5">{currentTrack.artist} · {currentTrack.album}</p>
          </div>
          <button onClick={() => toggleLikeTrack(currentTrack.id)}
            className="w-10 h-10 rounded-full bg-white/8 flex items-center justify-center active:scale-90 flex-shrink-0">
            <Heart className={`w-5 h-5 transition-all ${isLiked ? "fill-[#FF2D87] stroke-[#FF2D87] scale-110" : "stroke-white/40"}`} />
          </button>
        </div>

        {/* Seekbar */}
        <div className="px-1">
          <div
            ref={seekRef}
            className="relative h-8 flex items-center cursor-pointer group"
            onClick={handleSeek}
            onMouseDown={() => { isDragging.current = true; }}
            onMouseMove={(e) => { if (isDragging.current) handleSeek(e); }}
            onMouseUp={() => { isDragging.current = false; }}
            onTouchStart={handleSeek}
            onTouchMove={handleSeek}
          >
            <div className="w-full h-1 bg-white/15 rounded-full overflow-visible relative">
              <div className="h-full rounded-full transition-all duration-100" style={{ width: `${progressPct}%`, background: accentColor }} />
              <div className="absolute top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-white shadow-lg transition-all"
                style={{ left: `calc(${progressPct}% - 8px)` }} />
            </div>
          </div>
          <div className="flex justify-between text-[11px] text-white/35 font-mono -mt-1">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Transport Controls */}
        <div className="flex items-center justify-between px-2">
          <button onClick={toggleShuffle}
            className={`w-10 h-10 rounded-full flex items-center justify-center active:scale-90 transition-all ${isShuffleOn ? "bg-white/15" : "bg-transparent"}`}
            style={{ color: isShuffleOn ? accentColor : "rgba(255,255,255,0.3)" }}>
            <Shuffle className="w-5 h-5" />
          </button>
          <button onClick={prevTrack} className="w-12 h-12 rounded-full bg-white/8 flex items-center justify-center active:scale-90">
            <SkipBack className="w-6 h-6 text-white/80 fill-white/10" />
          </button>
          <button onClick={togglePlay}
            className="w-16 h-16 rounded-full flex items-center justify-center shadow-2xl active:scale-90 transition-transform"
            style={{ background: `linear-gradient(135deg, ${accentColor}, #7B61FF)`, boxShadow: `0 8px 30px ${accentColor}55` }}>
            {isPlaying ? <Pause className="w-7 h-7 fill-white text-white" /> : <Play className="w-7 h-7 fill-white text-white translate-x-0.5" />}
          </button>
          <button onClick={nextTrack} className="w-12 h-12 rounded-full bg-white/8 flex items-center justify-center active:scale-90">
            <SkipForward className="w-6 h-6 text-white/80 fill-white/10" />
          </button>
          <button onClick={toggleRepeat}
            className={`w-10 h-10 rounded-full flex items-center justify-center active:scale-90 relative ${repeatMode !== "off" ? "bg-white/15" : "bg-transparent"}`}
            style={{ color: repeatMode !== "off" ? accentColor : "rgba(255,255,255,0.3)" }}>
            <Repeat className="w-5 h-5" />
            {repeatMode === "one" && <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full text-black text-[8px] font-bold flex items-center justify-center" style={{ background: accentColor }}>1</span>}
          </button>
        </div>

        {/* Volume */}
        <div className="flex items-center gap-3 px-2 mt-1">
          <Volume2 className="w-4 h-4 text-white/30 flex-shrink-0" />
          <input type="range" min="0" max="1" step="0.01" value={volume}
            onChange={(e) => setVolume(parseFloat(e.target.value))}
            className="flex-1 h-1 rounded-full appearance-none cursor-pointer bg-white/15"
            style={{ accentColor }} />
          <span className="text-[11px] font-mono text-white/30 w-8 text-right">{Math.round(volume * 100)}%</span>
        </div>

        {/* DSP quick toggle */}
        <div className="flex items-center gap-2 px-1">
          <button onClick={toggleDsp}
            className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all ${dspEnabled ? "border-white/20 text-white/80 bg-white/8" : "border-white/5 text-white/25 bg-transparent"}`}
            style={{ borderColor: dspEnabled ? accentColor + "55" : undefined, color: dspEnabled ? accentColor : undefined }}>
            EQ {dspEnabled ? "ON" : "OFF"}
          </button>
          {connectedDevice && (
            <div className="flex-1 py-2 rounded-xl text-xs font-bold border border-white/10 bg-white/5 text-center text-white/60 truncate px-2">
              🎧 {connectedDevice.brand}
            </div>
          )}
        </div>

      </div>

      {/* LYRICS OVERLAY — double tap to open */}
      {showLyrics && (
        <div className="absolute inset-0 z-30 bg-[#0A0A0F]/95 backdrop-blur-xl rounded-3xl flex flex-col">
          <div className="flex items-center justify-between p-5 border-b border-white/8">
            <span className="font-bold text-white/90">Lyrics</span>
            <button onClick={() => setShowLyrics(false)} className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
              <X className="w-4 h-4 text-white/70" />
            </button>
          </div>
          <div ref={lyricsRef} className="flex-1 overflow-y-auto px-6 py-4 space-y-4 text-center">
            {currentTrack.lyricsSynced && currentTrack.lyricsSynced.length > 0 ? (
              currentTrack.lyricsSynced.map((line: any, idx: number) => (
                <p key={idx} data-active={idx === currentLyricIndex ? "true" : "false"}
                  onClick={() => seekTo(line.time)}
                  className={`text-base leading-relaxed cursor-pointer transition-all py-1 ${idx === currentLyricIndex ? "text-white font-bold scale-105" : "text-white/35"}`}
                  style={{ color: idx === currentLyricIndex ? accentColor : undefined }}>
                  {line.text}
                </p>
              ))
            ) : (
              <p className="text-white/30 text-sm mt-16">No lyrics available for this track.</p>
            )}
          </div>
        </div>
      )}

      {/* FULL SCREEN ART OVERLAY */}
      {showFullArt && (
        <div className="absolute inset-0 z-30 bg-black/95 rounded-3xl flex flex-col items-center justify-center" onClick={() => setShowFullArt(false)}>
          <img src={currentTrack.albumArtUri} alt={currentTrack.title} className="w-full h-full object-contain p-4" />
          <p className="absolute bottom-6 text-white/40 text-xs">Tap to close</p>
        </div>
      )}

      {/* QUEUE DRAWER */}
      {isQueueOpen && (
        <div className="absolute inset-0 z-30 bg-[#0A0A0F]/97 backdrop-blur-xl rounded-3xl flex flex-col">
          <div className="flex items-center justify-between p-5 border-b border-white/8">
            <span className="font-bold text-white/90">Queue ({queue.length})</span>
            <button onClick={() => setIsQueueOpen(false)} className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center">
              <X className="w-4 h-4 text-white/70" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto">
            {queue.map((track, idx) => {
              const isCurr = currentTrack.id === track.id;
              return (
                <div key={track.id + idx}
                  className={`flex items-center gap-3 px-5 py-3 border-b border-white/4 active:bg-white/5 cursor-pointer ${isCurr ? "bg-white/8" : ""}`}>
                  <img src={track.albumArtUri} alt="" className="w-10 h-10 rounded-lg object-cover flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-semibold truncate ${isCurr ? "text-white" : "text-white/70"}`} style={{ color: isCurr ? accentColor : undefined }}>{track.title}</p>
                    <p className="text-xs text-white/35 truncate">{track.artist}</p>
                  </div>
                  <span className="text-xs text-white/25 font-mono">{isCurr ? "▶" : formatTime(track.duration)}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
