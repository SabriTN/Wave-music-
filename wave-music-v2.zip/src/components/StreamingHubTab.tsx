import React, { useState } from "react";
import { usePlayer } from "../context/PlayerContext";
import { Link, Play, Search, Music, ExternalLink, AlertCircle } from "lucide-react";

const PUBLIC_STREAMS = [
  { title: "Ambient Space Journey", artist: "NASA Audio", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3", source: "Public Domain" },
  { title: "Lo-Fi Lounge Beats", artist: "Chilled Waves", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3", source: "Public Domain" },
  { title: "Electronic Pulse", artist: "SynthWave FM", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3", source: "Public Domain" },
  { title: "Acoustic Morning", artist: "Open Music Lab", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3", source: "Public Domain" },
  { title: "Jazz Improvisation", artist: "Free Jazz Archive", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3", source: "Public Domain" },
];

export const StreamingHubTab: React.FC = () => {
  const { addUrlTrack, accentColor, setActiveTab } = usePlayer();
  const [urlInput, setUrlInput] = useState("");
  const [urlTitle, setUrlTitle] = useState("");
  const [msg, setMsg] = useState<{type:"success"|"error"|"info", text:string}|null>(null);
  const [loading, setLoading] = useState(false);

  const handleUrlPlay = async () => {
    const url = urlInput.trim();
    if (!url) { setMsg({ type:"error", text:"Please enter a URL" }); return; }
    if (!url.startsWith("http")) { setMsg({ type:"error", text:"URL must start with http:// or https://" }); return; }

    setLoading(true);
    setMsg({ type:"info", text:"Connecting to stream…" });

    // Check if it's a YouTube URL — can only stream via backend/proxy in web context
    if (url.includes("youtube.com") || url.includes("youtu.be")) {
      setLoading(false);
      setMsg({ type:"error", text:"YouTube direct play requires the native Android build. Try a direct MP3/audio URL instead." });
      return;
    }

    const success = addUrlTrack(url, urlTitle || undefined);
    setLoading(false);
    if (success) {
      setMsg({ type:"success", text:"Stream added and playing! ▶" });
      setUrlInput(""); setUrlTitle("");
      setTimeout(() => setActiveTab("nowplaying"), 800);
    } else {
      setMsg({ type:"error", text:"Invalid URL. Please use a direct audio link (mp3, wav, flac, m4a, opus)." });
    }
  };

  const playPreset = (stream: typeof PUBLIC_STREAMS[0]) => {
    addUrlTrack(stream.url, stream.title, stream.artist);
    setMsg({ type:"success", text:`Playing: ${stream.title}` });
    setTimeout(() => setActiveTab("nowplaying"), 600);
  };

  return (
    <div className="flex flex-col h-full overflow-y-auto pb-24">
      <div className="px-5 pt-5 pb-4">
        <h1 className="text-2xl font-extrabold text-white">Streaming Hub</h1>
        <p className="text-xs text-white/35 mt-1">Play from direct audio URLs or public streams</p>
      </div>

      {/* URL Input */}
      <div className="px-5 mb-5">
        <div className="p-4 rounded-2xl bg-white/5 border border-white/10 space-y-3">
          <p className="text-xs font-bold text-white/50 uppercase tracking-wider flex items-center gap-2">
            <Link className="w-3.5 h-3.5" /> Play from URL
          </p>
          <input value={urlInput} onChange={e => setUrlInput(e.target.value)}
            placeholder="https://example.com/song.mp3"
            className="w-full bg-white/8 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-white/25 outline-none focus:border-white/20"
          />
          <input value={urlTitle} onChange={e => setUrlTitle(e.target.value)}
            placeholder="Track name (optional)"
            className="w-full bg-white/8 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white placeholder-white/25 outline-none focus:border-white/20"
          />
          <button onClick={handleUrlPlay} disabled={loading}
            className="w-full py-3 rounded-xl text-sm font-bold text-black transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2"
            style={{ background: accentColor }}>
            <Play className="w-4 h-4 fill-black" />
            {loading ? "Connecting…" : "Play Stream"}
          </button>

          {msg && (
            <div className={`p-3 rounded-xl text-xs font-medium ${msg.type === "success" ? "bg-green-500/15 text-green-400 border border-green-500/20" : msg.type === "error" ? "bg-red-500/15 text-red-400 border border-red-500/20" : "bg-blue-500/15 text-blue-400 border border-blue-500/20"}`}>
              {msg.text}
            </div>
          )}
        </div>
      </div>

      {/* Service availability */}
      <div className="px-5 mb-5">
        <p className="text-xs font-bold text-white/40 uppercase tracking-wider mb-3">Service Status</p>
        <div className="grid grid-cols-2 gap-2">
          {[
            { name:"Spotify", status:"Premium SDK", available: false, note:"Requires Spotify app" },
            { name:"YouTube", status:"Native only", available: false, note:"Requires Android build" },
            { name:"SoundCloud", status:"Public tracks", available: true, note:"Paste track URL above" },
            { name:"Direct URL", status:"Any MP3/FLAC", available: true, note:"Fully supported" },
            { name:"Internet Archive", status:"Free music", available: true, note:"Public domain" },
            { name:"Deezer", status:"SDK required", available: false, note:"Native build only" },
          ].map(svc => (
            <div key={svc.name} className={`p-3 rounded-2xl border ${svc.available ? "bg-white/5 border-white/10" : "bg-white/2 border-white/5 opacity-60"}`}>
              <div className="flex items-center justify-between mb-1">
                <span className="text-sm font-bold text-white/80">{svc.name}</span>
                <span className={`w-2 h-2 rounded-full ${svc.available ? "bg-green-400" : "bg-white/20"}`} />
              </div>
              <p className="text-[10px] text-white/35">{svc.note}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Public streams */}
      <div className="px-5">
        <p className="text-xs font-bold text-white/40 uppercase tracking-wider mb-3">🎵 Free Public Streams</p>
        <div className="space-y-2">
          {PUBLIC_STREAMS.map((s, i) => (
            <div key={i} className="flex items-center gap-3 p-3.5 rounded-2xl bg-white/5 border border-white/8 active:bg-white/8 cursor-pointer" onClick={() => playPreset(s)}>
              <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ background: `${accentColor}20` }}>
                <Music className="w-5 h-5" style={{ color: accentColor }} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white/85 truncate">{s.title}</p>
                <p className="text-xs text-white/35 truncate">{s.artist} · {s.source}</p>
              </div>
              <Play className="w-4 h-4 text-white/30 flex-shrink-0" />
            </div>
          ))}
        </div>

        <div className="mt-5 p-4 rounded-2xl bg-amber-500/8 border border-amber-500/20">
          <p className="text-xs font-bold text-amber-400 mb-1.5">💡 Want full streaming?</p>
          <p className="text-xs text-white/40 leading-relaxed">Full Spotify, YouTube, Deezer and SoundCloud streaming requires the native Android build using the Kotlin prompt. This web version supports direct audio URLs only.</p>
        </div>
      </div>
    </div>
  );
};
