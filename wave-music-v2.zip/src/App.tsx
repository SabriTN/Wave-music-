import React from "react";
import { PlayerProvider, usePlayer } from "./context/PlayerContext";
import { AudioVisualizer } from "./components/AudioVisualizer";
import { NowPlayingTab } from "./components/NowPlayingTab";
import { LibraryTab } from "./components/LibraryTab";
import { StreamingHubTab } from "./components/StreamingHubTab";
import { EqualizerTab } from "./components/EqualizerTab";
import { SettingsTab } from "./components/SettingsTab";
import { Play, Pause, SkipForward, Music, Library, Radio, Sliders, Settings } from "lucide-react";
import { formatTime } from "./utils/time";

function MasterPlayerLayout() {
  const {
    activeTab, setActiveTab, currentTrack, isPlaying, togglePlay,
    nextTrack, accentColor, currentTime, duration, progressPercent
  } = usePlayer();

  const renderView = () => {
    switch (activeTab) {
      case "nowplaying": return <NowPlayingTab />;
      case "home": return <LibraryTab />;
      case "streaming": return <StreamingHubTab />;
      case "equalizer": return <EqualizerTab />;
      case "settings": return <SettingsTab />;
      default: return <LibraryTab />;
    }
  };

  const NAV = [
    { id: "home", label: "Library", Icon: Library },
    { id: "streaming", label: "Stream", Icon: Radio },
    { id: "nowplaying", label: "Player", Icon: Music },
    { id: "equalizer", label: "EQ", Icon: Sliders },
    { id: "settings", label: "Settings", Icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-[#0A0A0F] text-white flex flex-col overflow-hidden" style={{ maxWidth: 480, margin: "0 auto" }}>

      {/* Global ambient bg */}
      <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-96 h-96 rounded-full blur-[120px] opacity-[0.07]" style={{ background: accentColor }} />
        <div className="absolute bottom-0 right-0 w-72 h-72 rounded-full blur-[100px] opacity-[0.04] bg-[#7B61FF]" />
      </div>

      {/* Main view */}
      <main className="relative z-10 flex-1 overflow-hidden" style={{ paddingBottom: currentTrack ? 128 : 72 }}>
        <div className="h-full overflow-y-auto">
          {renderView()}
        </div>
      </main>

      {/* Mini player — shown on all tabs except nowplaying */}
      {currentTrack && activeTab !== "nowplaying" && (
        <div className="fixed z-30 left-0 right-0" style={{ bottom: 64, maxWidth: 480, margin: "0 auto" }}>
          <div
            className="mx-3 p-3 rounded-2xl border border-white/10 backdrop-blur-xl flex items-center gap-3 cursor-pointer active:opacity-90"
            style={{ background: "rgba(18,18,26,0.92)" }}
            onClick={() => setActiveTab("nowplaying")}
          >
            {/* Progress bar */}
            <div className="absolute top-0 left-0 h-0.5 rounded-full transition-all duration-500" style={{ width: `${progressPercent}%`, background: accentColor }} />

            <img src={currentTrack.albumArtUri} alt="" className={`w-11 h-11 rounded-xl object-cover flex-shrink-0 ${isPlaying ? "animate-[spin_20s_linear_infinite]" : ""}`} style={{ borderRadius: "50%" }} />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-white truncate">{currentTrack.title}</p>
              <p className="text-xs text-white/40 truncate">{currentTrack.artist}</p>
            </div>
            <div className="flex items-center gap-1 flex-shrink-0">
              <button onClick={e => { e.stopPropagation(); togglePlay(); }}
                className="w-10 h-10 rounded-full flex items-center justify-center active:scale-90"
                style={{ background: accentColor }}>
                {isPlaying ? <Pause className="w-4 h-4 fill-black text-black" /> : <Play className="w-4 h-4 fill-black text-black translate-x-0.5" />}
              </button>
              <button onClick={e => { e.stopPropagation(); nextTrack(); }}
                className="w-10 h-10 rounded-full bg-white/8 flex items-center justify-center active:scale-90">
                <SkipForward className="w-4 h-4 text-white/70" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Nav */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 border-t border-white/8 backdrop-blur-xl" style={{ background: "rgba(10,10,15,0.92)", maxWidth: 480, margin: "0 auto" }}>
        <div className="flex items-center justify-around px-2 py-2">
          {NAV.map(({ id, label, Icon }) => {
            const active = activeTab === id;
            return (
              <button key={id} onClick={() => setActiveTab(id)}
                className="flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-all active:scale-90 relative min-w-0"
                style={{ color: active ? accentColor : "rgba(255,255,255,0.3)" }}>
                {active && <div className="absolute inset-0 rounded-xl opacity-10" style={{ background: accentColor }} />}
                <Icon className={`w-5 h-5 transition-transform ${active ? "scale-110" : ""}`} />
                <span className="text-[9px] font-bold uppercase tracking-wide">{label}</span>
                {id === "nowplaying" && isPlaying && (
                  <span className="absolute top-1 right-1 w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: accentColor }} />
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}

export default function App() {
  return (
    <PlayerProvider>
      <MasterPlayerLayout />
    </PlayerProvider>
  );
}
