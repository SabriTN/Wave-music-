/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export const formatTime = (seconds: number | undefined | null): string => {
  if (seconds === undefined || seconds === null || isNaN(seconds)) {
    return "0:00";
  }
  const cleanSecs = Math.max(0, Math.floor(seconds));
  const mins = Math.floor(cleanSecs / 60);
  const secs = cleanSecs % 60;
  return `${mins}:${secs < 10 ? "0" : ""}${secs}`;
};
