/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { EQBand, EQPreset } from "../types";

export const PARAMETRIC_FREQ_STAGES = [20, 60, 120, 250, 500, 1000, 2000, 4000, 8000, 16000];

export const BUILT_IN_PRESETS: EQPreset[] = [
  {
    id: "flat",
    name: "Flat",
    isBuiltIn: true,
    bands: PARAMETRIC_FREQ_STAGES.map(f => ({ frequency: f, gain: 0, q: 1.0 }))
  },
  {
    id: "rock",
    name: "Rock & Roll",
    isBuiltIn: true,
    bands: [
      { frequency: 20, gain: 4, q: 1.0 },
      { frequency: 60, gain: 3, q: 1.0 },
      { frequency: 120, gain: 1, q: 1.0 },
      { frequency: 250, gain: -1, q: 1.0 },
      { frequency: 500, gain: -2, q: 1.0 },
      { frequency: 1000, gain: -1, q: 1.0 },
      { frequency: 2000, gain: 1, q: 1.0 },
      { frequency: 4000, gain: 2, q: 1.0 },
      { frequency: 8000, gain: 3, q: 1.0 },
      { frequency: 16000, gain: 4, q: 1.0 }
    ]
  },
  {
    id: "pop",
    name: "Pop Vocal",
    isBuiltIn: true,
    bands: [
      { frequency: 20, gain: -1, q: 1.0 },
      { frequency: 60, gain: 1, q: 1.0 },
      { frequency: 120, gain: 2, q: 1.0 },
      { frequency: 250, gain: 3, q: 1.0 },
      { frequency: 500, gain: 1, q: 1.0 },
      { frequency: 1000, gain: -1, q: 1.0 },
      { frequency: 2000, gain: -2, q: 1.0 },
      { frequency: 4000, gain: 1, q: 1.0 },
      { frequency: 8000, gain: 2, q: 1.0 },
      { frequency: 16000, gain: 3, q: 1.0 }
    ]
  },
  {
    id: "bassplus",
    name: "Sub Bass+",
    isBuiltIn: true,
    bands: [
      { frequency: 20, gain: 7, q: 1.2 },
      { frequency: 60, gain: 6, q: 1.2 },
      { frequency: 120, gain: 4, q: 1.0 },
      { frequency: 250, gain: 2, q: 1.0 },
      { frequency: 500, gain: 0, q: 1.0 },
      { frequency: 1000, gain: -1, q: 1.0 },
      { frequency: 2000, gain: 0, q: 1.0 },
      { frequency: 4000, gain: 1, q: 1.0 },
      { frequency: 8000, gain: 2, q: 1.0 },
      { frequency: 16000, gain: 1, q: 1.0 }
    ]
  },
  {
    id: "electronic",
    name: "Electronic Pulsar",
    isBuiltIn: true,
    bands: [
      { frequency: 20, gain: 5, q: 1.0 },
      { frequency: 60, gain: 4, q: 1.0 },
      { frequency: 120, gain: 1, q: 1.0 },
      { frequency: 250, gain: 0, q: 1.0 },
      { frequency: 500, gain: -2, q: 1.0 },
      { frequency: 1000, gain: 0, q: 1.0 },
      { frequency: 2000, gain: 2, q: 1.0 },
      { frequency: 4000, gain: 1, q: 1.0 },
      { frequency: 8000, gain: 3, q: 1.0 },
      { frequency: 16000, gain: 5, q: 1.0 }
    ]
  }
];

export const BRAND_PROFILES = [
  {
    brand: "SONY",
    deviceName: "Sony WH-1000XM5 / WF Premium",
    gains: [2, 1, 0, 0, 2, 3, 2, 2, 1, 1],
    exciter: 0.15,
    stereoWidth: 0.25,
    description: "Lift focus vocals, widen mid-stage presence"
  },
  {
    brand: "SAMSUNG",
    deviceName: "Samsung Galaxy Buds Pro / AKG",
    gains: [3, 2, 1, 0, 1, 2, 1, 1, 0, 1],
    exciter: 0.1,
    stereoWidth: 0.15,
    description: "Harmonic lift targeting Harman curve reference signature"
  },
  {
    brand: "APPLE",
    deviceName: "Apple AirPods Pro / Max / Beats",
    gains: [4, 3, 2, 1, 0, 0, 1, 1, 0, 0],
    exciter: 0.2,
    stereoWidth: 0.3,
    description: "Enhance lower impact sub-bass, expand spatial bubble"
  },
  {
    brand: "BOSE",
    deviceName: "Bose QuietComfort Series",
    gains: [2, 3, 2, -1, 0, 1, 2, 1, 1, 0],
    exciter: 0.1,
    stereoWidth: 0.2,
    description: "Tame high-bass resonance and accent vocal clarity"
  },
  {
    brand: "JVC",
    deviceName: "JVC HA Extreme / Wooden Series",
    gains: [4, 5, 2, 1, 0, 1, 2, 3, 3, 2],
    exciter: 0.35,
    stereoWidth: 0.4,
    description: "Emphasize dynamic bass punch with custom harmonic excite sparkle"
  },
  {
    brand: "SENNHEISER",
    deviceName: "Sennheiser HD / Momentum series",
    gains: [0, 0, 1, 2, 2, 2, 1, 1, 0, 0],
    exciter: 0.05,
    stereoWidth: 0.1,
    description: "Highlight open-back depth with reference mid focus layers"
  }
];

export class AudioEngine {
  private ctx: AudioContext | null = null;
  public audio: HTMLAudioElement;
  private sourceNode: MediaElementAudioSourceNode | null = null;

  // Audio nodes routing
  private preGainNode: GainNode | null = null;
  private eqFilters: BiquadFilterNode[] = [];
  private compressorNode: DynamicsCompressorNode | null = null;
  private exciterShaper: WaveShaperNode | null = null;
  private exciterGain: GainNode | null = null;
  private dryExciterGain: GainNode | null = null;
  private exciterSum: GainNode | null = null;
  
  // Stereo Widener Nodes
  private widthDelayL: DelayNode | null = null;
  private widthDelayR: DelayNode | null = null;
  private widthSplitter: ChannelSplitterNode | null = null;
  private widthMerger: ChannelMergerNode | null = null;
  private widthGainNode: GainNode | null = null;
  private dryWidthGainNode: GainNode | null = null;
  private widthSumNode: GainNode | null = null;

  // Peak Limiter
  private limiterNode: DynamicsCompressorNode | null = null;
  private systemDSPBypassed: boolean = false;

  // Analyser
  public analyserNode: AnalyserNode | null = null;

  // Master Gain Node
  private masterGainNode: GainNode | null = null;

  // Settings
  private dspEnabled: boolean = true;
  private crossfadeDuration: number = 3.0; // seconds

  constructor() {
    this.audio = new Audio();
    this.audio.crossOrigin = "anonymous";
    this.audio.preload = "auto";
  }

  public setSource(src: string) {
    if (src.startsWith("blob:") || src.startsWith("data:")) {
      this.audio.removeAttribute("crossorigin");
    } else {
      this.audio.setAttribute("crossorigin", "anonymous");
    }
    this.audio.src = src;
  }

  public init() {
    if (this.ctx) return;

    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();
      
      // Create source
      this.sourceNode = this.ctx.createMediaElementSource(this.audio);

      // Create pre-gain
      this.preGainNode = this.ctx.createGain();
      this.preGainNode.gain.value = 1.0;

      // Create 10 cascading filters for parametric EQ
      PARAMETRIC_FREQ_STAGES.forEach((freq, idx) => {
        if (!this.ctx) return;
        const filter = this.ctx.createBiquadFilter();
        filter.frequency.value = freq;
        if (idx === 0) {
          filter.type = "lowshelf";
        } else if (idx === PARAMETRIC_FREQ_STAGES.length - 1) {
          filter.type = "highshelf";
        } else {
          filter.type = "peaking";
        }
        filter.Q.value = 1.0;
        filter.gain.value = 0;
        this.eqFilters.push(filter);
      });

      // Create Compressor
      this.compressorNode = this.ctx.createDynamicsCompressor();
      this.compressorNode.threshold.value = -12.0; // dB
      this.compressorNode.ratio.value = 3.0;
      this.compressorNode.attack.value = 0.01; // 10ms
      this.compressorNode.release.value = 0.15; // 150ms

      // Soft Saturation Harmonic Exciter (WaveShaper approach)
      this.exciterShaper = this.ctx.createWaveShaper();
      this.exciterShaper.curve = this.makeSaturationCurve(3.0);
      this.exciterGain = this.ctx.createGain();
      this.exciterGain.gain.value = 0.0; // Default off (controlled via exciter slider)
      this.dryExciterGain = this.ctx.createGain();
      this.dryExciterGain.gain.value = 1.0;
      this.exciterSum = this.ctx.createGain();

      // Haas Delay Stereo Widener
      this.widthSplitter = this.ctx.createChannelSplitter(2);
      this.widthMerger = this.ctx.createChannelMerger(2);
      this.widthDelayL = this.ctx.createDelay(0.1);
      this.widthDelayR = this.ctx.createDelay(0.1);
      this.widthDelayL.delayTime.value = 0.0;
      this.widthDelayR.delayTime.value = 0.015; // 15ms Haas delay on right channel
      
      this.widthGainNode = this.ctx.createGain();
      this.widthGainNode.gain.value = 0.0; // Default off
      this.dryWidthGainNode = this.ctx.createGain();
      this.dryWidthGainNode.gain.value = 1.0;
      this.widthSumNode = this.ctx.createGain();

      // True Peak Limiter (Aggressive compressor to avoid digital clipping)
      this.limiterNode = this.ctx.createDynamicsCompressor();
      this.limiterNode.threshold.value = -1.0; // -1 dBTP ceiling
      this.limiterNode.knee.value = 0;
      this.limiterNode.ratio.value = 20.0;
      this.limiterNode.attack.value = 0.001; // 1ms look-ahead feel
      this.limiterNode.release.value = 0.05; // 50ms fast limit release

      // Master Volume Control
      this.masterGainNode = this.ctx.createGain();
      this.masterGainNode.gain.value = 1.0;

      // Analyser Node
      this.analyserNode = this.ctx.createAnalyser();
      this.analyserNode.fftSize = 512;

      // CONNECT EVERYTHING
      // Pipeline: 
      // Source -> PreGain -> EQ [0..9] -> Dynamic Compressor -> Exciter (Parallel) -> Widener (Parallel) -> Limiter -> Master Volume -> Analyser -> Output

      this.sourceNode.connect(this.preGainNode);

      // LinkEQ stage cascading
      let currentInput: AudioNode = this.preGainNode;
      this.eqFilters.forEach(filter => {
        currentInput.connect(filter);
        currentInput = filter;
      });

      // Connect EQ output to Compressor
      currentInput.connect(this.compressorNode);

      // Exciter Parallel block
      // Dry Exciter Node
      this.compressorNode.connect(this.dryExciterGain);
      this.dryExciterGain.connect(this.exciterSum);
      // Wet WaveShaper Node
      this.compressorNode.connect(this.exciterShaper);
      this.exciterShaper.connect(this.exciterGain);
      this.exciterGain.connect(this.exciterSum);

      // Stereo Widener Parallel Block
      // Dry Path
      this.exciterSum.connect(this.dryWidthGainNode);
      this.dryWidthGainNode.connect(this.widthSumNode);
      // Wet Path (Haas Splitter & Delay)
      this.exciterSum.connect(this.widthSplitter);
      this.widthSplitter.connect(this.widthDelayL, 0); // L out to L in
      this.widthSplitter.connect(this.widthDelayR, 1); // R out to R in
      
      // Let's feed them back merged
      this.widthDelayL.connect(this.widthMerger, 0, 0);
      this.widthDelayR.connect(this.widthMerger, 0, 1);
      
      this.widthMerger.connect(this.widthGainNode);
      this.widthGainNode.connect(this.widthSumNode);

      // Connect sum node to Limiter
      this.widthSumNode.connect(this.limiterNode);

      // Connect Limiter to Master Gain
      this.limiterNode.connect(this.masterGainNode);

      // Connect Master Gain to Analyser
      this.masterGainNode.connect(this.analyserNode);

      // Connect Analyser to Destination
      this.analyserNode.connect(this.ctx.destination);
    } catch (e) {
      console.error("Failed to initialize Web Audio Pipeline. Bypassing.", e);
    }
  }

  // Create customized soft-clipping/harmonic waveshape curves
  private makeSaturationCurve(amount: number) {
    const k = typeof amount === 'number' ? amount : 50;
    const n_samples = 44100;
    const curve = new Float32Array(n_samples);
    const deg = Math.PI / 180;
    for (let i = 0 ; i < n_samples; ++i ) {
      const x = (i * 2) / n_samples - 1;
      // 2nd and 3rd order harmonic saturation formula
      curve[i] = ( (3 + k) * x * 20 * deg ) / ( Math.PI + k * Math.abs(x) );
    }
    return curve;
  }

  // Real-time parameters manipulation
  public setEqGain(bandIdx: number, value: number) {
    this.init();
    if (this.eqFilters[bandIdx]) {
      const targetGain = this.dspEnabled ? value : 0;
      // Ramp smoothly to avoid zipper clicks
      const currentTime = this.ctx ? this.ctx.currentTime : 0;
      this.eqFilters[bandIdx].gain.setValueAtTime(this.eqFilters[bandIdx].gain.value, currentTime);
      this.eqFilters[bandIdx].gain.linearRampToValueAtTime(targetGain, currentTime + 0.05);
    }
  }

  public setExciterIntensity(value: number) {
    // scale exciter slider 0..1 to wet-path gain multiplier
    this.init();
    if (this.exciterGain && this.dryExciterGain) {
      const targetGain = this.dspEnabled ? value * 0.45 : 0;
      const currentTime = this.ctx ? this.ctx.currentTime : 0;
      this.exciterGain.gain.setValueAtTime(this.exciterGain.gain.value, currentTime);
      this.exciterGain.gain.linearRampToValueAtTime(targetGain, currentTime + 0.05);
      
      // Reduce dry offset slightly with excitement to gainstage nicely
      this.dryExciterGain.gain.setValueAtTime(this.dryExciterGain.gain.value, currentTime);
      this.dryExciterGain.gain.linearRampToValueAtTime(1.0 - (targetGain * 0.3), currentTime + 0.05);
    }
  }

  public setStereoWidth(value: number) {
    // scale stereo width slider 0..1 to wet delay-mix
    this.init();
    if (this.widthGainNode && this.dryWidthGainNode) {
      const targetGain = this.dspEnabled ? value * 0.75 : 0;
      const currentTime = this.ctx ? this.ctx.currentTime : 0;
      this.widthGainNode.gain.setValueAtTime(this.widthGainNode.gain.value, currentTime);
      this.widthGainNode.gain.linearRampToValueAtTime(targetGain, currentTime + 0.05);

      // Gain stabilization
      this.dryWidthGainNode.gain.setValueAtTime(this.dryWidthGainNode.gain.value, currentTime);
      this.dryWidthGainNode.gain.linearRampToValueAtTime(1.0 - (targetGain * 0.2), currentTime + 0.05);
    }
  }

  public setCompressorParams(enabled: boolean, thresholdStr: number = -12.0) {
    this.init();
    if (this.compressorNode) {
      const currentTime = this.ctx ? this.ctx.currentTime : 0;
      if (enabled && this.dspEnabled) {
        this.compressorNode.threshold.linearRampToValueAtTime(thresholdStr, currentTime + 0.05);
        this.compressorNode.ratio.linearRampToValueAtTime(3.5, currentTime + 0.05);
      } else {
        // Zero out reduction by making threshold high
        this.compressorNode.threshold.linearRampToValueAtTime(0.0, currentTime + 0.05);
        this.compressorNode.ratio.linearRampToValueAtTime(1.0, currentTime + 0.05);
      }
    }
  }

  public setDspEnabled(enabled: boolean) {
    this.dspEnabled = enabled;
    // Notify filters and elements to bypass
    this.eqFilters.forEach((filter, idx) => {
      this.setEqGain(idx, filter.gain.value);
    });
    // Toggle nodes directly
    if (this.exciterGain && this.widthGainNode) {
      const exciterVal = this.exciterGain.gain.value;
      const widthVal = this.widthGainNode.gain.value;
      this.setExciterIntensity(enabled && exciterVal > 0 ? 0.3 : 0);
      this.setStereoWidth(enabled && widthVal > 0 ? 0.3 : 0);
    }
  }

  public isDspEnabled() {
    return this.dspEnabled;
  }

  public setMasterVolume(vol: number) {
    this.init();
    if (this.masterGainNode) {
      const currentTime = this.ctx ? this.ctx.currentTime : 0;
      this.masterGainNode.gain.setValueAtTime(this.masterGainNode.gain.value, currentTime);
      this.masterGainNode.gain.linearRampToValueAtTime(vol, currentTime + 0.04);
    }
  }

  // System Dolby atmos detection fallback toggle
  public setDolbyBypass(bypass: boolean) {
    this.systemDSPBypassed = bypass;
    if (bypass) {
      // Force disable extreme processors to avoid conflict
      this.setStereoWidth(0);
      this.setExciterIntensity(0);
    }
  }

  public isDolbyBypassed() {
    return this.systemDSPBypassed;
  }

  public resumeContext() {
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume();
    }
  }
}

// Global Exportable instance
export const engine = new AudioEngine();
