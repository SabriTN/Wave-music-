/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Programmatic uncompressed WAV synthesizer to generate beautiful, CORS-free,
 * high-fidelity uncompressed CD-quality PCM audio files on the fly.
 * This guarantees the player operates perfectly offline, with zero network load.
 */
export function generateSynthesizedWav(type: "neon" | "chopin" | "lofi" | "acoustic", durationSecs: number = 20): string {
  const sampleRate = 22050; // 22.05 kHz is perfect balance of lightweight memory footprint and sound fidelity
  const numChannels = 1; // mono
  const bitsPerSample = 16;
  const blockAlign = numChannels * (bitsPerSample / 8);
  const byteRate = sampleRate * blockAlign;
  const numSamples = sampleRate * durationSecs;
  const subChunk2Size = numSamples * blockAlign;
  const chunkSize = 36 + subChunk2Size;

  // Buffer allocation
  const buffer = new ArrayBuffer(44 + subChunk2Size);
  const view = new DataView(buffer);

  // RIFF Header
  writeString(view, 0, "RIFF");
  view.setUint32(4, chunkSize, true);
  writeString(view, 8, "WAVE");

  // fmt Subchunk
  writeString(view, 12, "fmt ");
  view.setUint32(16, 16, true); // Subchunk1Size
  view.setUint16(20, 1, true); // AudioFormat (1 = PCM)
  view.setUint16(22, numChannels, true);
  view.setUint32(24, sampleRate, true);
  view.setUint32(28, byteRate, true);
  view.setUint16(32, blockAlign, true);
  view.setUint16(34, bitsPerSample, true);

  // data Subchunk
  writeString(view, 36, "data");
  view.setUint32(40, subChunk2Size, true);

  // Audio Data synthesis
  let offset = 44;

  if (type === "neon") {
    // Neon Horizon: Arpeggiated synthesizer with filter sweep
    const chords = [110, 130.81, 146.83, 164.81]; // A, C, D, E basses
    const notes = [220, 261.63, 293.66, 329.63, 392.00, 440.00, 523.25, 587.33]; // synthwave pentatonic scales

    for (let i = 0; i < numSamples; i++) {
      const t = i / sampleRate;

      // Bass drone with slow LFO
      const bassFreq = chords[Math.floor(t / 4) % chords.length];
      const bassLfo = Math.sin(2 * Math.PI * 0.15 * t);
      const bassVal = Math.sin(2 * Math.PI * bassFreq * t) * (0.2 + 0.05 * bassLfo);

      // Fast arpeggiator
      const arpSpeed = 6; // notes per second
      const arpNoteIndex = Math.floor(t * arpSpeed) % notes.length;
      const arpFreq = notes[arpNoteIndex];
      
      // Plucky decay envelope
      const noteTime = (t * arpSpeed) % 1;
      const env = Math.exp(-4 * noteTime);

      // Square wave with LFO sweep to represent resonance sweep
      const sweepLfo = Math.sin(2 * Math.PI * 0.2 * t);
      const wave = Math.sin(2 * Math.PI * arpFreq * t) > sweepLfo ? 1 : -1;
      const leadVal = wave * env * 0.12;

      // Delay effect line
      const delayTime = Math.floor(sampleRate * 0.3); // 300ms delay
      let delayVal = 0;
      if (i > delayTime) {
        // Simple mock feedback reading past amplitude values
        const pastIndex = offset - delayTime * blockAlign;
        if (pastIndex >= 44) {
          delayVal = view.getInt16(pastIndex, true) / 32768.1 * 0.35;
        }
      }

      // Mix & Gain Stage
      const rawMixed = (bassVal + leadVal + delayVal) * 0.6;
      const sample = Math.max(-1, Math.min(1, rawMixed));
      view.setInt16(offset, sample < 0 ? sample * 32768 : sample * 32767, true);
      offset += blockAlign;
    }
  } else if (type === "chopin") {
    // Chopin Nocturne: Elegant minor chord cadence using rich multi-sine harmonic layers
    // Chopin Nocturne: beautiful slowly decaying romantic piano-like notes
    const melody = [
      { f: 329.63, start: 0, dur: 2 },  // E4
      { f: 349.23, start: 2, dur: 1 },  // F4
      { f: 392.00, start: 3, dur: 1 },  // G4
      { f: 523.25, start: 4, dur: 4 },  // C5
      { f: 493.88, start: 8, dur: 2 },  // B4
      { f: 440.00, start: 10, dur: 2 }, // A4
      { f: 392.00, start: 12, dur: 4 }, // G4
      { f: 349.23, start: 16, dur: 4 }  // F4
    ];

    const basses = [
      { f: 130.81, start: 0, dur: 4 },  // C3
      { f: 196.00, start: 4, dur: 4 },  // G3
      { f: 220.00, start: 8, dur: 4 },  // A3
      { f: 174.61, start: 12, dur: 4 }, // F3
      { f: 196.00, start: 16, dur: 4 }  // G3
    ];

    for (let i = 0; i < numSamples; i++) {
      const t = i / sampleRate;

      // Bass accompaniment
      let bassMix = 0;
      const activeBass = basses.find(b => t >= b.start && t < b.start + b.dur);
      if (activeBass) {
        // Soft hammond/piano warm harmonics
        const ft = t - activeBass.start;
        const env = Math.exp(-1.5 * ft);
        bassMix = (
          Math.sin(2 * Math.PI * activeBass.f * t) * 0.25 + 
          Math.sin(2 * Math.PI * activeBass.f * 2 * t) * 0.08
        ) * env;
      }

      // Melody lines
      let melMix = 0;
      const activeNote = melody.find(m => t >= m.start && t < m.start + m.dur);
      if (activeNote) {
        const ft = t - activeNote.start;
        const env = Math.exp(-2.2 * ft);
        // Multi-harmonic sine to simulate acoustic string vibration
        melMix = (
          Math.sin(2 * Math.PI * activeNote.f * t) * 0.28 +
          Math.sin(2 * Math.PI * activeNote.f * 2 * t) * 0.12 +
          Math.sin(2 * Math.PI * activeNote.f * 3 * t) * 0.05
        ) * env;
      }

      const rawMixed = (bassMix + melMix) * 0.55;
      const sample = Math.max(-1, Math.min(1, rawMixed));
      view.setInt16(offset, sample < 0 ? sample * 32768 : sample * 32767, true);
      offset += blockAlign;
    }
  } else if (type === "lofi") {
    // Lofi Rainfall: Soft jazz chords with periodic vinyl crackle emulation
    const chords = [
      [146.83, 174.61, 220.00, 261.63], // Dm7 (D3, F3, A3, C4)
      [116.54, 146.83, 174.61, 220.00], // Bbmaj7 (Bb2, D3, F3, A3)
      [130.81, 164.81, 196.00, 246.94], // Cmaj7 (C3, E3, G3, B3)
      [110.00, 130.81, 164.81, 196.00]  // Am7 (A2, C3, E3, G3)
    ];

    for (let i = 0; i < numSamples; i++) {
      const t = i / sampleRate;

      // Smooth triangle chord pad
      const chordIndex = Math.floor(t / 5) % chords.length;
      const activeChord = chords[chordIndex];
      let chordVal = 0;
      
      activeChord.forEach((freq) => {
        // Math.abs( (time*freq)%2 - 1 ) * 2 - 1 calculates a clean triangle wave
        const tri = Math.abs(((t * freq) % 1) - 0.5) * 4 - 1;
        chordVal += tri * 0.06;
      });

      // Lofi lowpass filter simulation
      const paddleEnv = Math.sin(2 * Math.PI * 0.21 * t) * 0.02;
      chordVal = chordVal + paddleEnv;

      // Vinyl crackle noise emulation
      let noiseVal = 0;
      if (Math.random() > 0.992) {
        // Impulse click
        noiseVal = (Math.random() - 0.5) * 0.28;
      } else {
        // Ambient background crackle noise
        noiseVal = (Math.random() - 0.5) * 0.015;
      }

      const rawMixed = (chordVal + noiseVal) * 0.65;
      const sample = Math.max(-1, Math.min(1, rawMixed));
      view.setInt16(offset, sample < 0 ? sample * 32768 : sample * 32767, true);
      offset += blockAlign;
    }
  } else {
    // Acoustic Serenade: plucked strings using Karplus-Strong adjacent feedback delay algorithm
    // Let's create an elegant acoustic plucked chord arpeggio loop instead
    const guitarChords = [196.00, 246.94, 293.66, 392.00]; // G Major arpeggio
    for (let i = 0; i < numSamples; i++) {
      const t = i / sampleRate;
      
      // Fast plucks
      const plSpeed = 2; // two plucks per sec
      const pluckTime = (t * plSpeed) % 1;
      const pluckIdx = Math.floor(t * plSpeed) % guitarChords.length;
      const pluckFreq = guitarChords[pluckIdx];

      const plEnv = Math.exp(-5 * pluckTime);
      // Soft guitar pluck harmonic profile
      const toneVal = (
        Math.sin(2 * Math.PI * pluckFreq * t) * 0.22 +
        Math.sin(2 * Math.PI * pluckFreq * 2.02 * t) * 0.12 +
        Math.sin(2 * Math.PI * pluckFreq * 3.01 * t) * 0.06
      ) * plEnv;

      // Mix in smooth sub bass drone
      const droneVal = Math.sin(2 * Math.PI * 98.00 * t) * 0.15 * Math.sin(Math.PI * t / durationSecs);

      const rawMixed = (toneVal + droneVal) * 0.5;
      const sample = Math.max(-1, Math.min(1, rawMixed));
      view.setInt16(offset, sample < 0 ? sample * 32768 : sample * 32767, true);
      offset += blockAlign;
    }
  }

  // Create Blob and obtain temporary URL
  const blob = new Blob([buffer], { type: "audio/wav" });
  return URL.createObjectURL(blob);
}

function writeString(view: DataView, offset: number, string: string): void {
  for (let i = 0; i < string.length; i++) {
    view.setUint8(offset + i, string.charCodeAt(i));
  }
}
